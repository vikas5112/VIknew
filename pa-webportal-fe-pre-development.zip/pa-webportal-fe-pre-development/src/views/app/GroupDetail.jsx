import React, { useEffect, useState } from "react";
import {
  Container,
  Row,
  Col,
  Card,
  Dropdown,
  Button,
  Modal,
  OverlayTrigger,
  Tooltip,
  Form,
} from "react-bootstrap";
import { Link, useParams, useHistory } from "react-router-dom";
import { groupDetail as groupDetailActions } from "../../store/groups/groupDetailSlice";
import { useDeleteGroupMutation } from "../../store/group/groupApiSlice";
import { useDispatch, useSelector } from "react-redux";
import {
  useCreateGroupPostMutation,
  useGetPostsQuery,
  useFeedUploadMutation,
  useGetUrlMetaMutation,
  useGetPostsForGroupQuery,
  useLikeCommentMutation,
  useLikePostMutation,
  useCreateCommentMutation
} from "../../store/post/postApiSlice";
import TextEditor from "../../components/TextEditor";
import RenderFile from "../../components/RenderFile";
import FeedBlock from "../../components/FeedBlock"

//image
import img1 from "../../assets/images/page-img/gi-1.jpg";
import user1 from "../../assets/images/user/05.jpg";
import user2 from "../../assets/images/user/06.jpg";
import user3 from "../../assets/images/user/07.jpg";
import user4 from "../../assets/images/user/08.jpg";
import user5 from "../../assets/images/user/09.jpg";
import user6 from "../../assets/images/user/10.jpg";
import user7 from "../../assets/images/user/11.jpg";
import user8 from "../../assets/images/user/12.jpg";
import user9 from "../../assets/images/user/1.jpg";
import img5 from "../../assets/images/user/1.jpg";
import small1 from "../../assets/images/small/07.png";
import small2 from "../../assets/images/small/08.png";
import small3 from "../../assets/images/small/09.png";
import small4 from "../../assets/images/small/10.png";
import small5 from "../../assets/images/small/11.png";
import small6 from "../../assets/images/small/12.png";
import small7 from "../../assets/images/small/13.png";
import small8 from "../../assets/images/small/14.png";
import img6 from "../../assets/images/user/04.jpg";
import img7 from "../../assets/images/page-img/52.jpg";
import img8 from "../../assets/images/user/04.jpg";
import img9 from "../../assets/images/page-img/60.jpg";
import img10 from "../../assets/images/user/02.jpg";
import img11 from "../../assets/images/user/03.jpg";
import header from "../../assets/images/page-img/profile-bg7.jpg";
import icon1 from "../../assets/images/icon/01.png";
import icon2 from "../../assets/images/icon/02.png";
import icon3 from "../../assets/images/icon/03.png";
import icon4 from "../../assets/images/icon/04.png";
import icon5 from "../../assets/images/icon/05.png";
import icon6 from "../../assets/images/icon/06.png";
import icon7 from "../../assets/images/icon/07.png";
import CustomToggle from "../../components/Dropdowns";
import ShareOffcanvas from "../../components/ShareOffcanvas";



const GroupDetail = () => {
  const [show, setShow] = useState(false);
  const handleClose = () => {
    setTextEditorData(null);
    setUrlDetails({})
    setFile(null)
    setShow(false)
  };
  const handleShow = () => setShow(true);
  const { groupDetail } = useSelector(state => state.groupDetail);
  const dispatch = useDispatch()
  const { group_id } = useParams()
  const [createGroupPost] = useCreateGroupPostMutation();
  const userInfo = useSelector((state) => state.user.userDetails);
  let userId = userInfo?._id;
  const [deleteGroup] = useDeleteGroupMutation();
  const [feedUpload] = useFeedUploadMutation();
  // const getPost = useGetPostsQuery();
  const getGroupPosts = useGetPostsForGroupQuery(group_id);
  const [file, setFile] = useState(null);
  const [textEditorData, setTextEditorData] = useState(null);
  const [urlDetails, setUrlDetails] = useState({});
  const [allPosts, setAllPosts] = useState([]);

  const [likePost] = useLikePostMutation();
  const [likeComment] = useLikeCommentMutation();
  const [commentPost] = useCreateCommentMutation();

  const [getUrlMeta] = useGetUrlMetaMutation();
  const detailGroup = groupDetail[0]


  const fetchUrlDetails = async (url) => {
    const result = await getUrlMeta({
      url: url,
    });
    if (result?.data?.status === 1 && result?.data?.data) {
      setUrlDetails(result?.data?.data)
    }
  };

  const getGroupDetail = () => {
    fetch(
      `https://pa-webportal-api.janbaskplatform-development.com/api/groups/get-group-details/${group_id}`,
      {
        method: "GET",
        headers: {
          authorization: `Bearer ${localStorage.getItem("token")}`,
          "content-type": "application/json",
        },
      }
    )
      .then((response) => {
        if (response.ok) {
          response.json().then((data) => {
            dispatch(groupDetailActions(data.data));
          });
        } else {
        }
      })
      .catch((error) => { });
  };

  useEffect(() => {
    getGroupDetail()
  }, [])
  useEffect(() => {
    if (getGroupPosts?.data?.status === 1 && Array.isArray(getGroupPosts?.data?.data) && getGroupPosts?.data?.data.length > 0) {
      setAllPosts(getGroupPosts?.data?.data);
    }
  }, [getGroupPosts?.data]);
  const history = useHistory();
  const goBack = () => {
    history.goBack()
  }



  const handleDeleteGroup = async () => {
    if (window.confirm("Are you sure! You want to delete this group?")) {
      let result = await deleteGroup({ group_id: group_id })
      if (result.data.status === 1) {
        history.push("/dashboards/app/groups");
      }
    }
  }
  const uploadMediaHandle = (fileData) => {
    setFile(fileData);
  };

  const handleLike = async (id) => {
    const result = await likePost({
      post_id: id,
    });
  };

  const handleCommentLike = async (post_id, comment_id) => {
    const result = await likeComment({
      post_id: post_id,
      comment_id: comment_id
    });
  };

  const handleComment = async (id, comment) => {
    const result = await commentPost({
      post_id: id,
      comment_text: comment,
      parent_comment: ''
    });
    if (result?.data?.status === 1) {
      getGroupPosts.refetch();
    }
  };
  const handleReply = async (comment_id, post_id, text) => {
    const result = await commentPost({
      parent_comment: comment_id,
      post_id: post_id,
      comment_text: text,

    });
    if (result?.data?.status === 1) {
      getGroupPosts.refetch();
    }
  }


  const handleSubmit = async () => {
    let multerData = new FormData();

    multerData.append("file", file);

    let payload;
    let url_meta_data = {}
    if (urlDetails) {
      url_meta_data = { ...urlDetails }
    }

    if (file) {
      const feedRes = await feedUpload(multerData);
      payload = {
        text_editor_data: textEditorData,
        file_id: feedRes?.data?.data?.data?._id,
        file_url: feedRes?.data?.data?.data?.file_url,
        group_id: detailGroup?._id,
      };
      if (feedRes?.data?.status === 1) {
      } else {
        console.log("something error in group post");
        return;
      }
    } else {
      payload = {
        text_editor_data: textEditorData,
        group_id: detailGroup?._id,
      };
    }
    const result = await createGroupPost({ ...payload, url_meta_data: url_meta_data });
    if (result?.data?.status === 1) {
      getGroupPosts.refetch();
      setFile(null);
      handleClose();
    }
  };

  return (
    <>
      <Container>
        <div id="content-page" className="content-page">
          <img src={detailGroup?.background_image} style={{ width: '100%', height: '200px', borderRadius: "5px" }} />
          <Row>
            <Col lg="12">
              <div className="d-flex align-items-center justify-content-between mb-3 mt-3 flex-wrap">
                <div className="group-info d-flex align-items-center">
                  <div className="me-3">
                    <img
                      className="rounded-circle img-fluid avatar-100"
                      src={detailGroup?.group_image}
                      alt=""
                    />
                  </div>
                  <div className="info">
                    <h4>{detailGroup?.title}</h4>
                    <p className="mb-0">
                      <i className="ri-lock-fill pe-2"></i>{detailGroup?.is_public ? "Public Group" : "Private Group"} . {detailGroup?.members_subset.length}
                      members
                    </p>
                    {detailGroup?.owner?.ref === userId ? <button className="btn btn-primary d-block w-100" onClick={handleDeleteGroup}>
                      Delete Group
                    </button> : null}
                  </div>
                </div>
                <div
                  mt-md="0"
                  mt="2"
                  className="group-member d-flex align-items-center"
                >
                  <div className="iq-media-group me-4 d-flex align-items-center">

                    {detailGroup?.members_subset?.slice(0, 3).map(() => {
                      return <Link to="#" className="iq-media">
                        <img
                          className="img-fluid avatar-40 rounded-circle"
                          src={user7}
                          alt=""
                        />
                      </Link>
                    })}
                    <h4 className="ms-1">(+{detailGroup?.members_subset?.length - 3 === - 1 || detailGroup?.members_subset?.length - 3 === - 2 ? (0) : detailGroup?.members_subset?.length - 3})</h4>
                  </div>
                  <Link to="/dashboards/app/add-member-group">
                    <Button variant="primary" className="mb-2 me-2">
                      <i className="ri-add-line me-2"></i>Add Member
                    </Button>
                  </Link>
                  <Button onClick={goBack}
                    className="btn btn-primary me-1 mb-2"

                  >
                    Back
                  </Button>
                </div>
              </div>
            </Col>

            <Col lg="8">
              <Card id="post-modal-data">
                <Card.Header className="d-flex justify-content-between">
                  <div className="header-title">
                    <h4 className="card-title">Create Post</h4>
                  </div>
                </Card.Header>
                <Card.Body>
                  <div className="d-flex align-items-center">
                    <Link to="/dashboard/app/profile">
                      <div className="user-img">
                        <img
                          src={
                            userInfo?.profile_picture
                              ? userInfo?.profile_picture
                              : "https://jbpbucket-dev.s3.amazonaws.com/devjanbask/profile_pic/f65d1d56-5887-4abb-b4f1-a3100975g718.jpg"
                          }
                          alt="user1"
                          className="avatar-60 rounded-circle"
                        />
                      </div>
                    </Link>
                    <form
                      className="post-text ms-3 w-100 "
                      onClick={handleShow}
                    >
                      <input
                        type="text"
                        className="form-control rounded"
                        placeholder="Write something here..."
                        style={{ border: "none" }}
                      />
                    </form>
                  </div>
                  <hr />

                </Card.Body>
                <Modal show={show} onHide={handleClose} size="lg">
                  <Modal.Header className="d-flex justify-content-between">
                    <Modal.Title id="post-modalLabel">Create Post</Modal.Title>
                    <Link to="#" className="lh-1" onClick={handleClose}>
                      <span className="material-symbols-outlined">close</span>
                    </Link>
                  </Modal.Header>
                  <Modal.Body>
                    <div className="d-flex align-items-center">
                      <div className="user-img">
                        <img
                          src={
                            userInfo?.profile_picture
                              ? userInfo?.profile_picture
                              : "https://jbpbucket-dev.s3.amazonaws.com/devjanbask/profile_pic/f65d1d56-5887-4abb-b4f1-a3100975g718.jpg"
                          }
                          alt="user1"
                          className="avatar-60 rounded-circle img-fluid"
                        />
                      </div>
                      <form
                        className="post-text ms-3 w-100 "
                        data-bs-toggle="modal"
                        data-bs-target="#post-modal"
                      >
                        <TextEditor
                          textEditorData={textEditorData}
                          onChange={setTextEditorData}

                          urlDetails={urlDetails}
                          fetchUrlDetails={fetchUrlDetails}
                        />
                        {/* <input
                          type="text"
                          className="form-control rounded"
                          onChange={handleTextChange}
                          placeholder="Write something here..."
                          style={{ border: "none" }}
                        /> */}
                      </form>
                    </div>
                    <hr />
                    <ul className="d-flex flex-wrap align-items-center list-inline m-0 p-0">
                      <li className="col-md-6 mb-3">
                        <div className="bg-soft-primary rounded p-2 pointer me-3">
                          <label className="shareOption">
                            <span>Photo/Video</span>

                            <input
                              style={{ display: "none" }}
                              type="file"
                              id="file"
                              //  accept=".png,.jpeg,.jpg"
                              onChange={(e) => {
                                uploadMediaHandle(e.target.files[0]);
                              }}
                            />
                          </label>
                        </div>
                      </li>
                      <RenderFile file={file} filetype={"filetype"} />
                    </ul>
                    <hr />

                    <button
                      type="submit"
                      className="btn btn-primary d-block w-100 mt-3"
                      onClick={handleSubmit}
                    >
                      Post
                    </button>
                  </Modal.Body>
                </Modal>
              </Card>
              {allPosts?.map((val) => (
                <FeedBlock postDetails={val} handleLike={handleLike} handleComment={handleComment} handleCommentLike={handleCommentLike} handleReply={handleReply} getPost={getGroupPosts} />
              ))}
            </Col>
            <Col lg="4">
              <Card>
                <Card.Header className="card-header d-flex justify-content-between">
                  <Link to="/dashboards/app/create-group">
                    <button
                      type="submit"
                      className="btn btn-primary d-block w-100"
                    >
                      <i className="ri-add-line pe-2"></i>Create New Group
                    </button></Link>
                  {detailGroup?.owner?.ref === userId ? <Link to={`/dashboards/app/edit-group-detail/${group_id}`}>
                    <button className="btn btn-primary d-block w-100">
                      Edit Group
                    </button></Link> : null}
                </Card.Header>
              </Card>
              <Card>
                <Card.Header className="card-header d-flex justify-content-between">
                  <div className="header-title">
                    <h4 className="card-title">About</h4>
                  </div>
                </Card.Header>
                <Card.Body>
                  <ul className="list-inline p-0 m-0">
                    <li className="mb-3">
                      <p className="mb-0">{detailGroup?.title}.</p>
                    </li>
                    <li className="mb-3">
                      <div className="d-flex">
                        <div className="flex-shrink-0">
                          <i className="material-symbols-outlined">lock</i>
                        </div>
                        <div className="flex-grow-1 ms-3">
                          <h6>Group Type</h6>
                          <p className="mb-0">
                            {detailGroup?.is_public ? "Public" : "Private"}
                          </p>
                        </div>
                      </div>
                    </li>
                    <li>
                      <div className="d-flex">
                        <div className="flex-shrink-0">
                          <i className="material-symbols-outlined">group</i>
                        </div>
                        <div className="flex-grow-1 ms-3">
                          <h6>Group Owner</h6>
                          <p className="mb-0">
                            {detailGroup?.owner.username}
                          </p>
                        </div>
                      </div>
                    </li>
                  </ul>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </div>
      </Container>
    </>
  );
};

export default GroupDetail;
