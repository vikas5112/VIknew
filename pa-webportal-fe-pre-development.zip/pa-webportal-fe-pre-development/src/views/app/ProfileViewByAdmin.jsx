import React, { useState } from "react";
import {useParams} from "react-router-dom";
import { useSelector } from "react-redux";


import {
  Row,
  Col,
  Container,
  Card,

} from "react-bootstrap";


import img1 from "../../assets/images/page-img/profile-bg1.jpg";


import loader from "../../assets/images/page-img/page-load-loader.gif";


import backgroundImg from '../../assets/images/bg/bg.jpg';

const  ProfileViewByAdmin = () => {

    const { i } = useParams();
    const userList = useSelector((state) => state.userList);
  

    const userData =userList.userList[i]


  return (
    <>
     
      <Container>
        <Row>
          <Col sm={12}>
            <Card>
              <Card.Body className=" profile-page p-0">
                <div className="profile-header">
                  <div className="position-relative">
                    <img
                      loading="lazy"
                      style={{height:"350px",width:"100%"}}
                      src={userData?.backgournd_picture || img1}
                      alt="profile-bg"
                      className="rounded img-fluid"/>
                    </div>
                  <div className="user-detail text-center mb-3">
                    <div className="profile-img">
                      <img style = {{height:"130px",width:"130px"}}
                        loading="lazy"
                        src={userData.profile_picture || "https://jbpbucket-dev.s3.amazonaws.com/devjanbask/profile_pic/f65d1d56-5887-4abb-b4f1-a3100975g718.jpg"}
                        alt="profile-img1"
                        className="avatar-130 img-fluid"
                      />
                    </div>
                    <div className="profile-detail">
                      <h3>{userData?.first_name + " " + userData?.last_name}</h3>
                    </div>
                  </div>
                  <div className="profile-info p-3 d-flex align-items-center justify-content-between position-relative">
                    <div className="social-info">
                      <ul className="social-data-block d-flex align-items-center justify-content-between list-inline p-0 m-0">
                        <li className="text-center ps-3">
                          <h6>Posts</h6>
                          <p className="mb-0">0</p>
                        </li>
                        <li className="text-center ps-3">
                          <h6>Connections</h6>
                          <p className="mb-0">{userData?.connection_count}</p>
                          
                        </li>
                        <li className="text-center ps-3">
                          <h6>Invitations</h6>
                          <p className="mb-0">0</p>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </Card.Body>
            </Card>
          </Col>
              <Row>
                      <Col md={12} className=" ps-4">
                        <Card>
                          <Card.Body>
                                <h4>Personal Info</h4>
                                <hr />
                                <Row className="mb-2">
                                  <div className="col-3">
                                    <h6>First name :</h6>
                                  </div>
                                  <div className="col-3">
                                    <p className="mb-0">{userData?.first_name}</p>
                                  </div>
                                  <div className="col-3">
                                    <h6>Last name :</h6>
                                  </div>
                                  <div className="col-3">
                                    <p className="mb-0">{userData?.last_name}</p>
                                  </div>
                                </Row>
                           
                                {userData?.first_name && (
                                  <Row className="mb-2">
                                    <div className="col-3">
                                      <h6>UserName :</h6>
                                    </div>
                                    <div className="col-3">
                                      <p className="mb-0">
                                        {userData?.first_name + " " + userData?.last_name}
                                      </p>
                                    </div>
                                    <div className="col-3">
                                      <h6>Phone Number :</h6>
                                    </div>
                                    <div className="col-3">
                                      <p className="mb-0">
                                        {userData?.phone}
                                      </p>
                                    </div>
                                  </Row>
                                )}
                                {userData?.user_type && (
                                  <Row className="mb-2">
                                    <div className="col-3">
                                      <h6>Usertype :</h6>
                                    </div>
                                    <div className="col-3">
                                      <p className="mb-0">
                                        {userData?.user_type}
                                      </p>
                                    </div>
                                    <div className="col-3">
                                    <h6>Email :</h6>
                                  </div>
                                  <div className="col-3">
                                    <p className="mb-0">{userData?.email}</p>
                                  </div>
                                  </Row>
                                )}
                          </Card.Body>
                        </Card>
                      </Col>
                    </Row>
              
                {/* <div className="col-sm-12 text-center">
                  <img
                    loading="lazy"
                    src={loader}
                    alt="loader"
                    style={{ height: "100px" }}
                  />
                </div> */}
        </Row>
      </Container>
    </>
  );
};

export default ProfileViewByAdmin;
