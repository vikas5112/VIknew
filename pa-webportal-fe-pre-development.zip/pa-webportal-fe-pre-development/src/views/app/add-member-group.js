import React, { useState, useEffect } from "react";
import { Row, Col, Container, Form, Card } from "react-bootstrap";

import { Link, useHistory } from "react-router-dom";
import {
  useGetConnectionQuery,
  useUpdateStatusMutation,
} from "../../store/connection/connectionApiSlice";

import user05 from "../../assets/images/user/05.jpg";
import { useSelector } from "react-redux";
import { useAddMemberMutation } from "../../store/group/groupApiSlice";
import { useRemoveMemberMutation } from "../../store/group/groupApiSlice";

const AddMemberGroup = () => {
  const [allConnections, setAllConnections] = useState([]);
  const [displayConnections, setDisplayConnections] = useState([]);
  const { data } = useGetConnectionQuery();
  const [updateStatus] = useUpdateStatusMutation();
  const [addMember] = useAddMemberMutation();
  const [removeMember] = useRemoveMemberMutation()
  const { groupDetail } = useSelector((state) => state.groupDetail);

  const history = useHistory();

  const onHandleSearchChange = async (e) => {
    let connectionSearchData = e.target.value;
    e.preventDefault();
    var tempArr = [];
    allConnections.map((item) => {
      let fullName = item.requested?.username;
      const lData = fullName.toLowerCase();
      if (lData.includes(connectionSearchData.toLowerCase())) {
        tempArr.push(item);
      }
    });

    setDisplayConnections(tempArr);
  };

  const handleBlock = async (id) => {
    const res = await updateStatus({
      id: id,
      status: "blocked",
    });
    if (res?.data?.status === 1) {
      let newList = displayConnections.filter((val) => val._id != id);
      setDisplayConnections(newList);
    }
  };
  const memberAdd = async (member_id) => {
    let result = await addMember({
      group_id: groupDetail[0]?._id,
      member_id,
    });
    if (result?.data?.status === 1) {
      // addAlert(true)
      history.push(`/dashboards/app/group-detail/${groupDetail[0]?._id}`);
    }
  };

  const memberRemove = async (member_id) => {
    let result = await removeMember({
      group_id: groupDetail[0]?._id,
      member_id,
    });
    if (result?.data?.status === 1) {
      // addAlert(true)
      history.push(`/dashboards/app/group-detail/${groupDetail[0]?._id}`);
    }
  };

  useEffect(() => {
    if (data && data?.status === 1 && data?.data?.length > 0) {
      setAllConnections(data?.data);
      setDisplayConnections(data?.data);
    }
  }, [data]);
console.log("displayConnections", displayConnections)
  return (
    <>
      <Container>
        <Row>
          <Col sm="12">
            <Card>
              <Card.Header className="d-flex justify-content-between">
                <div className="header-title">
                  <h4 className="card-title">Add Connections to Group</h4>
                </div>
                <div className="iq-search-bar device-search">
                  <Form action="#" className="searchbox">
                    <div className="search-link">
                      <span className="material-symbols-outlined">search </span>
                    </div>
                    <Form.Control
                      type="text"
                      className="text search-input bg-soft-primary"
                      placeholder="Search Connection"
                      onChange={(event) => onHandleSearchChange(event)}
                    />
                  </Form>
                </div>
              </Card.Header>
              <Card.Body>
                <ul className="request-list list-inline m-0 p-0">
                  {displayConnections?.map((val) => (
                    <li className="d-flex align-items-center  justify-content-between flex-wrap">
                      <div className="user-img img-fluid flex-shrink-0">
                        <img
                          src={user05}
                          alt="story-img"
                          className="rounded-circle avatar-40"
                        />
                      </div>
                      <div className="flex-grow-1 ms-3">
                        <h6>{val.requested.username}</h6>
                        {/* <p className="mb-0">40 friends</p> */}
                      </div>
                      <div className="d-flex align-items-center mt-2 mt-md-0">
                        <div className="confirm-click-btn">
                          {groupDetail[0]?.members_subset.filter(
                            (ele) => ele.ref === val.requested.ref
                          ).length > 0 ? (
                            <div
                              className="btn btn-secondary rounded"
                              data-extra-toggle="delete"
                              data-closest-elem=".item"
                              onClick={()=>memberRemove(val.requested.ref)}
                            >
                              Remove
                            </div>
                          ) : (
                            <div
                              className="btn btn-primary rounded confirm-btn"
                              onClick={() => memberAdd(val.requested.ref)}
                            >
                              Add in Group
                            </div>
                          )}
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default AddMemberGroup;
