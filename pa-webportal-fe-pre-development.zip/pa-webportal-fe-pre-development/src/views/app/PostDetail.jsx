import React, { useEffect, useState } from "react";
import {
  Container,
  Row,
  Col,
  Card,
  Dropdown,
  Button,
  Modal,
} from "react-bootstrap";
import { Link, useParams, useHistory } from "react-router-dom";
import { groupDetail as groupDetailActions } from "../../store/groups/groupDetailSlice";
import { useDeleteGroupMutation } from "../../store/group/groupApiSlice";
import { useDispatch, useSelector } from "react-redux";
import {
  useCreateGroupPostMutation,
  useGetPostsQuery,
  useFeedUploadMutation,
  useGetUrlMetaMutation,
  useGetPostsForGroupQuery,
  useLikeCommentMutation,
  useLikePostMutation,
  useCreateCommentMutation
} from "../../store/post/postApiSlice";
import TextEditor from "../../components/TextEditor";
import RenderFile from "../../components/RenderFile";
import FeedBlock from "../../components/FeedBlock"

//image
import img1 from "../../assets/images/page-img/gi-1.jpg";
import user1 from "../../assets/images/user/05.jpg";
import user2 from "../../assets/images/user/06.jpg";
import user3 from "../../assets/images/user/07.jpg";
import user4 from "../../assets/images/user/08.jpg";
import user5 from "../../assets/images/user/09.jpg";
import user6 from "../../assets/images/user/10.jpg";
import user7 from "../../assets/images/user/11.jpg";
import user8 from "../../assets/images/user/12.jpg";
import user9 from "../../assets/images/user/1.jpg";
import img5 from "../../assets/images/user/1.jpg";
import small1 from "../../assets/images/small/07.png";
import small2 from "../../assets/images/small/08.png";
import small3 from "../../assets/images/small/09.png";
import small4 from "../../assets/images/small/10.png";
import small5 from "../../assets/images/small/11.png";
import small6 from "../../assets/images/small/12.png";
import small7 from "../../assets/images/small/13.png";
import small8 from "../../assets/images/small/14.png";
import img6 from "../../assets/images/user/04.jpg";
import img7 from "../../assets/images/page-img/52.jpg";
import img8 from "../../assets/images/user/04.jpg";
import img9 from "../../assets/images/page-img/60.jpg";
import img10 from "../../assets/images/user/02.jpg";
import img11 from "../../assets/images/user/03.jpg";
import header from "../../assets/images/page-img/profile-bg7.jpg";
import icon1 from "../../assets/images/icon/01.png";
import icon2 from "../../assets/images/icon/02.png";
import icon3 from "../../assets/images/icon/03.png";
import icon4 from "../../assets/images/icon/04.png";
import icon5 from "../../assets/images/icon/05.png";
import icon6 from "../../assets/images/icon/06.png";
import icon7 from "../../assets/images/icon/07.png";
import CustomToggle from "../../components/Dropdowns";
import ShareOffcanvas from "../../components/ShareOffcanvas";



const PostDetail = () => {
  const [postDetail,setPostDetail]=useState({})
  const [show, setShow] = useState(false);
  const handleClose = () => {
    setTextEditorData(null);
    setUrlDetails({})
    setFile(null)
    setShow(false)
  };
  const handleShow = () => setShow(true);
  const { groupDetail } = useSelector(state => state.groupDetail);
  const dispatch = useDispatch()
  const { group_id } = useParams()
  const [createGroupPost] = useCreateGroupPostMutation();
  const userInfo = useSelector((state) => state.user.userDetails);
  let userId = userInfo?._id;
  const [deleteGroup] = useDeleteGroupMutation();
  const [feedUpload] = useFeedUploadMutation();
  // const getPost = useGetPostsQuery();
  const getGroupPosts = useGetPostsForGroupQuery(group_id);
  const [file, setFile] = useState(null);
  const [textEditorData, setTextEditorData] = useState(null);
  const [urlDetails, setUrlDetails] = useState({});
  const [allPosts, setAllPosts] = useState([]);

  const [likePost] = useLikePostMutation();
  const [likeComment] = useLikeCommentMutation();
  const [commentPost] = useCreateCommentMutation();

  const [getUrlMeta] = useGetUrlMetaMutation();
  const detailGroup = groupDetail[0]

  
  const fetchUrlDetails = async(url) => {
    const result = await getUrlMeta({
      url: url,
    });
    if(result?.data?.status === 1 && result?.data?.data){
      setUrlDetails(result?.data?.data)
    }
  };

  const getGroupDetail = () => {
    fetch(
      `https://pa-webportal-api.janbaskplatform-development.com/api/groups/get-group-details/${group_id}`,
      {
        method: "GET",
        headers: {
          authorization: `Bearer ${localStorage.getItem("token")}`,
          "content-type": "application/json",
        },
      }
    )
      .then((response) => {
        if (response.ok) {
          response.json().then((data) => {
            dispatch(groupDetailActions(data.data));
          });
        } else {
        }
      })
      .catch((error) => { });
  };

  useEffect(() => {
    getGroupDetail()
  }, [])
console.log(getGroupPosts?.data?.data,"getGroupPostschcekw")
  useEffect(() => {
    if (getGroupPosts?.data?.status === 1 && Array.isArray(getGroupPosts?.data?.data) && getGroupPosts?.data?.data.length>0) {
      setAllPosts(getGroupPosts?.data?.data);
    }
  }, [getGroupPosts?.data]);
  const history = useHistory();
  const goBack = () => {
    history.goBack()
  }



  const handleDeleteGroup = async () => {
    if (window.confirm("Are you sure! You want to delete this group?")) {
      let result = await deleteGroup({ group_id: group_id })
      if (result.data.status === 1) {
        history.push("/dashboards/app/groups");
      }
    }
  }
  const uploadMediaHandle = (fileData) => {
    setFile(fileData);
  };

  const handleLike = async (id) => {
    const result = await likePost({
      post_id: id,
    });
  };

  const handleCommentLike = async (post_id, comment_id) => {
    const result = await likeComment({
      post_id: post_id,
      comment_id:comment_id
    });
  };

  const handleComment = async (id, comment) => {
    const result = await commentPost({
      post_id: id,
      comment_text: comment,
      parent_comment:''
    });
    if (result?.data?.status === 1) {
      getGroupPosts.refetch();
    }
  };
  const handleReply = async (comment_id, post_id, text)=>{
    const result = await commentPost({
      parent_comment:  comment_id,
      post_id : post_id,
      comment_text: text,
     
    });
    if (result?.data?.status === 1) {
      getGroupPosts.refetch();
    }
  }


  const handleSubmit = async () => {
    let multerData = new FormData();

    multerData.append("file", file);

    let payload;
    let url_meta_data={}
    if(urlDetails){
      url_meta_data={...urlDetails}
    }

    if (file) {
      const feedRes = await feedUpload(multerData);
      payload = {
        text_editor_data: textEditorData,
        file_id: feedRes?.data?.data?.data?._id,
        file_url: feedRes?.data?.data?.data?.file_url,
        group_id: detailGroup?._id,
      };
      if (feedRes?.data?.status === 1) {
      } else {
        console.log("something error in group post");
        return;
      }
    } else {
      payload = {
        text_editor_data: textEditorData,
        group_id: detailGroup?._id,
      };
    }
    const result = await createGroupPost({...payload,url_meta_data:url_meta_data});
    if (result?.data?.status === 1) {
      getGroupPosts.refetch();
      setFile(null);
      handleClose();
    }
  };

  return (
    <>
      <Container>
      <FeedBlock postDetails={postDetail} handleLike={handleLike} handleComment={handleComment} handleCommentLike={handleCommentLike} handleReply={handleReply} getPost={getPost}/>

      </Container>
    </>
  );
};

export default PostDetail;
