import React from "react";
import user05 from "../../assets/images/user/05.jpg";
import user01 from "../../assets/images/user/01.jpg";
import user02 from "../../assets/images/user/02.jpg";
import user03 from "../../assets/images/user/03.jpg";
import { Link } from "react-router-dom";
import { useState } from "react";
import { getDate } from "../../utilities/time";

function RenderComment({ objData, handleReply, post_id, handleCommentLike }) {
  let timeObj = getDate(objData.createdAt);

  let [show, setShow] = useState(false);
  let [isLike, setIsLike] = useState(false);
  let [likeCount, setLikeCount] = useState(0);
  const [text, setText] = useState({
    comment_text: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();

    handleReply(objData.ref, post_id, text.comment_text);
    setSubmitted(true);
    setShow(false);
    setText({
      comment_text: "",
    });
  };
  const handleChange = (e) => {
    setSubmitted(false);
    setText({ ...text, [e.target.name]: e.target.value });
  };

  function handleCount() {
    if (isLike) {
      setLikeCount(likeCount - 1);
      setIsLike(false);
    } else {
      setLikeCount(likeCount + 1);
      setIsLike(true);
    }
  }
  function handleInput() {
    setShow(true);
  }
  return (
    <div>
      <ul className="post-comments p-0 m-0">
        <li className="mb-2">
          <div className="d-flex flex-wrap">
            <div className="user-img">
              <img
                loading="lazy"
                src={user02}
                alt="userimg"
                className="avatar-35 rounded-circle img-fluid"
              />
            </div>
            <div className="comment-data-block  ms-3">
              <h6>{objData.name}</h6>{" "}
              <span>
                {" "}
                {timeObj.hours > 0
                  ? timeObj.hours > 23
                    ? `on ${timeObj?.timeStart.toDateString()}`
                    : `${Math.floor(timeObj.hours)} hour ago`
                  : `${Math.floor(timeObj.minutes)} min ago`}{" "}
              </span>
              <p className="mb-0">{objData.comment_text}</p>
              <div className="d-flex gap-2 flex-wrap align-items-center comment-activity">
                {/* <div className="total-like-block ms-2 me-3">
                  <span
                    onClick={() => {
                      handleCommentLike(post_id, objData._id);
                      if (isLike) {
                        setLikeCount(likeCount - 1);
                        setIsLike(false);
                      } else {
                        setLikeCount(likeCount + 1);
                        setIsLike(true);
                      }
                    }}
                  >
                    <i
                      className={
                        isLike ? "fas fa-thumbs-down" : "fas fa-thumbs-up"
                      }
                    ></i>
                  </span>{" "}
                  {`${likeCount} Likes`}
                </div> */}

                <button className="border-0 btn btn-link" onClick={handleInput}>
                  Reply
                </button>
              </div>
              {show && (
                <form onSubmit={handleSubmit}>
                  <div className=" d-flex  ">
                    <input
                      name="comment_text"
                      type="text"
                      className="form-control rounded"
                      placeholder="Enter your comment"
                      value={text.comment_text}
                      onChange={(e) => handleChange(e)}
                    ></input>
                    <span>
                      <button
                        className="border-0  btn btn-link"
                        type="submit"
                        onClick={handleSubmit}
                      >
                        <i className="fa fa-paper-plane"></i>
                      </button>
                    </span>
                  </div>
                </form>
              )}
               {/* <div className="text-center">
              <Link
                to="dashboards/app/invitation-list"
                className=" btn text-primary"
              >
                View full post
              </Link>
            </div> */}
            </div>
           
          </div>
        </li>
      </ul>
    </div>
  );
}

export default RenderComment;
