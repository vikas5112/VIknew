import { useEffect } from "react";
import { Alert, Container, Form } from "react-bootstrap";
import Card from "../../components/Card";
import { Link, useHistory } from "react-router-dom";
import { useSelector } from "react-redux";
import {
    useAddMemberMutation,
    useGetGroupsQuery,
} from "../../store/group/groupApiSlice";
// images
import defaultBg from "../../assets/images/bg/bg.jpg";
import user05 from "../../assets/images/user/05.jpg";
import { useState } from "react";
const Groups = () => {
    const userInfo = useSelector((state) => state.user.userDetails);
    let userId = userInfo?._id;
    const [group, setGroup] = useState([]);
    const [allGroup, setAllGroup] = useState([]);
    const [addAlert, setAddAlert] = useState(false);
    const { data, refetch } = useGetGroupsQuery();
    const [addMember] = useAddMemberMutation();
    const history = useHistory();
    const memberAdd = async (group_id) => {
        let result = await addMember({
            group_id,
            member_id: userId,
        });
        if (result?.data?.status === 1) {
            history.push(`/dashboards/app/group-detail/${group_id}`);
        }
    };
    const onHandleSearchChange = (e) => {
        e.preventDefault();
        let groupSearchData = e.target.value;
        var tempArr = [];
        allGroup.map((item) => {
            let groupName = item?.title;
            const lData = groupName.toLowerCase();
            if (lData.includes(groupSearchData.toLowerCase())) {
                tempArr.push(item);
            }
        });
        setGroup(tempArr);
    }
    useEffect(() => {
        if (data && data.status === 1) {
            setAllGroup(data?.data)
            setGroup(data.data);
        }
    }, [data]);

    return (
        <>
            <div className="card container">
                <Card.Header className="d-flex justify-content-between">
                    <div className="header-title">
                        <h4 className="card-title">Groups ({group?.length})</h4>
                    </div>
                    <div className="iq-search-bar device-search">
                        <Form action="#" className="searchbox">
                            <div className="search-link">
                                <span className="material-symbols-outlined">search </span>
                            </div>
                            <Form.Control
                                type="text"
                                className="text search-input bg-soft-primary"
                                placeholder="Search Groups"
                                onChange={(event) => onHandleSearchChange(event)}
                            />
                        </Form>
                    </div>

                    <div>
                        <button type="button" className="btn btn-primary">
                            {" "}
                            <Link
                                to="/dashboards/app/create-group"
                                style={{ color: "white" }}
                            >
                                CREATE GROUP
                            </Link>{" "}
                        </button>
                    </div>
                </Card.Header>
            </div>

            <div className="container" style={{ height: "200px", color: "white" }}>
                <img
                    src="https://www.pasecondarytransition.com/assets21/webpimages/Practices-ban.webp"
                    style={{ width: "100%", height: "100%", borderRadius: "5px" }}
                />
            </div>

            <div id="content-page" className="content-page">
                <Container>
                    <div className="d-grid gap-3 d-grid-template-1fr-19 mb-3">
                        {group?.map((item, i) => {
                            var match = false;
                            return (
                                <Card className="mb-0">
                                    <div className="top-bg-image">
                                        <img
                                            src={
                                                item.background_image
                                                    ? item.background_image
                                                    : defaultBg
                                            }
                                            className="img-fluid w-100"
                                            style={{ height: "150px", objectFit: "cover" }}
                                            alt="group-bg"
                                        />
                                    </div>
                                    <Card.Body className=" text-center" key={i}>
                                        <div className="group-icon">
                                            <img
                                                src={item.group_image || "https://jbpbucket-dev.s3.amazonaws.com/devjanbask/profile_pic/f65d1d56-5887-4abb-b4f1-a3100975g718.jpg"}
                                                alt="profile-img"
                                                className="rounded-circle img-fluid avatar-120"
                                            />
                                        </div>
                                        <div className="group-info pt-3 pb-3">
                                            <h4>
                                                <Link to={`/dashboards/app/group-detail/${item._id}`}>
                                                    {item.title}
                                                </Link>
                                            </h4>
                                            {item.is_public ? <p>Public</p> : <p>Private</p>}
                                            <p className="mb-0">Owner</p>
                                            <h5>{item.owner.username}</h5>
                                        </div>
                                        <div className="group-details d-inline-block pb-3">
                                            <ul className="d-flex align-items-center justify-content-between list-inline m-0 p-0">
                                                <li className="pe-3 ps-3">
                                                    <p className="mb-0">Member</p>
                                                    <h6>{item?.members_subset?.length}</h6>
                                                </li>

                                            </ul>
                                        </div>


                                        {item.members_subset.map((item) => {
                                            if (item.ref === userId) {
                                                match = true;
                                            }
                                            return;
                                        })}
                                        {console.log("match", match)}
                                        {match ? (
                                            <button
                                                type="submit"
                                                className="btn btn-primary d-block w-100 btn-col"
                                                style={{ backgroundColor: "#35aba0", border: "none" }}
                                            >
                                                Joined
                                            </button>
                                        ) : (
                                            <>
                                                <button
                                                    type="submit"
                                                    className="btn btn-primary d-block w-100 btn-col"
                                                    onClick={() => memberAdd(item._id)}
                                                >
                                                    Join
                                                </button>
                                                {/* <Alert
                          variant="alert alert-success"
                          show={addAlert}
                          onClose={() => setAddAlert(false)}
                          dismissible
                        >
                          <span>
                            <i className="fas fa-thumbs-up"></i>
                          </span>
                          <span> Added successfully!</span>
                        </Alert> */}
                                            </>
                                        )}
                                    </Card.Body>
                                </Card>
                            );
                        })}
                    </div>
                </Container>
            </div>
        </>
    );
};

export default Groups;
