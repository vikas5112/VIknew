import React, { useState, useEffect } from "react";
import { Row, Col, Container, Form } from "react-bootstrap";
import Card from "../../components/Card";
import { Link } from "react-router-dom";
import { useGetInvitationsQuery,useUpdateStatusMutation } from "../../store/connection/connectionApiSlice";
import { useSelector } from "react-redux";

// img

import user5 from "../../assets/images/user/05.jpg";
import user6 from "../../assets/images/user/06.jpg";
import user7 from "../../assets/images/user/07.jpg";
import user8 from "../../assets/images/user/08.jpg";
import user9 from "../../assets/images/user/09.jpg";
import user10 from "../../assets/images/user/10.jpg";
import user11 from "../../assets/images/user/11.jpg";
import user12 from "../../assets/images/user/12.jpg";
import user13 from "../../assets/images/user/13.jpg";
import user14 from "../../assets/images/user/14.jpg";
import user15 from "../../assets/images/user/15.jpg";
import user16 from "../../assets/images/user/16.jpg";
import user17 from "../../assets/images/user/17.jpg";
//Sweet alert
import Swal from "sweetalert2";
import { setUser } from "../../store/user/action";
import { useDispatch } from "react-redux";

const FriendReqest = () => {
  const userInfo = useSelector((state)=>state.user.userDetails)
  const dispatch = useDispatch()
  const [allInvitations, setAllInvitations] = useState([]);
  const [displayInvitations, setDisplayInvitations] = useState([]);
  const { data } = useGetInvitationsQuery();
   const [updateStatus] =useUpdateStatusMutation()
  useEffect(() => {
    if (data && data?.status === 1 && data?.data?.data?.length > 0) {
      setAllInvitations(data?.data?.data);
      setDisplayInvitations(data?.data?.data);
    }
  }, [data]);
 
  const onHandleSearchChange = async (e) => {
    let invitationSearchData = e.target.value;
    e.preventDefault();
    var tempArr = [];
    allInvitations.map((item) => {
      let fullName = item.requester?.username;
      const lData = fullName.toLowerCase();
      if (lData.includes(invitationSearchData.toLowerCase())) {
        tempArr.push(item);
      }
    });

    setDisplayInvitations(tempArr);
  };

  const questionAlert = () => {
    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        cancelButton: "btn btn-outline-primary btn-lg ms-2",
        confirmButton: "btn btn-primary btn-lg",
      },
      buttonsStyling: false,
    });

    swalWithBootstrapButtons
      .fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        cancelButtonText: "cancel",
        confirmButtonText: "Yes, delete it!",

        reverseButtons: false,
        showClass: {
          popup: "animate__animated animate__zoomIn",
        },
        hideClass: {
          popup: "animate__animated animate__zoomOut",
        },
      })
      .then((result) => {
        if (result.isConfirmed) {
          swalWithBootstrapButtons.fire({
            title: "Deleted!",
            text: "Your Request has been deleted.",
            icon: "success",
            showClass: {
              popup: "animate__animated animate__zoomIn",
            },
            hideClass: {
              popup: "animate__animated animate__zoomOut",
            },
          });
        } else if (
          /* Read more about handling dismissals below */
          result.dismiss === Swal.DismissReason.cancel
        ) {
          swalWithBootstrapButtons.fire({
            title: "Your Request is safe!",
            showClass: {
              popup: "animate__animated animate__zoomIn",
            },
            hideClass: {
              popup: "animate__animated animate__zoomOut",
            },
          });
        }
      });
  };

  const handleConfirm =async (id) => {
     const res = await updateStatus({
        id: id,
        status: "active",
      });
      if(res?.data?.status===1){
      let newList=displayInvitations.filter(val=>val._id!=id)
      setDisplayInvitations(newList)
   }
   userInfo.connection_count = userInfo.connection_count + 1;
   userInfo.invitation_count = userInfo.invitation_count - 1;
   dispatch(setUser(userInfo))

  };

  const handleReject =async (id) => {
   const res = await updateStatus({
      id: id,
      status: "decline",
    });
    if(res?.data?.status===1){
    let newList=displayInvitations.filter(val=>val._id!=id)
    setDisplayInvitations(newList)
    userInfo.invitation_count = userInfo.invitation_count - 1
    dispatch(setUser(userInfo))
 }

};
  return (
    <>
      <Container>
        <Row>
          <Col sm="12">
            <Card>
              <Card.Header className="d-flex justify-content-between">
                <div className="header-title">
                  <h4 className="card-title">Invitations ({userInfo?.invitation_count})</h4>
                </div>
                <div className="iq-search-bar device-search">
                  <Form action="#" className="searchbox">
                    <div className="search-link">
                      <span className="material-symbols-outlined">search</span>
                    </div>
                    <Form.Control
                      type="text"
                      className="text search-input bg-soft-primary"
                      placeholder="Search inviations"
                      onChange={(event) => onHandleSearchChange(event)}
                    />
                  </Form>
                </div>
              </Card.Header>
              <Card.Body>
                <ul className="request-list list-inline m-0 p-0">
                  {displayInvitations.map((val) => (
                    <li className="d-flex align-items-center  justify-content-between flex-wrap">
                      <div className="user-img img-fluid flex-shrink-0">
                        <img
                          src={user5}
                          alt="story-img"
                          className="rounded-circle avatar-40"
                        />
                      </div>
                      <div className="flex-grow-1 ms-3">
                        <h6>{val.requester.username}</h6>
                        {/* <p className="mb-0">40 friends</p> */}
                      </div>
                      <div className="d-flex align-items-center mt-2 mt-md-0">
                        <div
                          className="confirm-click-btn"
                          onClick={()=>handleConfirm(val._id)}
                        >
                          <div className="me-3 btn btn-primary rounded confirm-btn">
                            Confirm
                          </div>

                          <Link
                            to="#"
                            className="me-3 btn btn-primary rounded request-btn"
                            style={{ display: "none" }}
                          >
                            View All
                          </Link>
                        </div>
                        <div
                          onClick={()=>handleReject(val._id)}
                          className="btn btn-secondary rounded"
                          data-extra-toggle="delete"
                          data-closest-elem=".item"
                        >
                          Reject
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default FriendReqest;
