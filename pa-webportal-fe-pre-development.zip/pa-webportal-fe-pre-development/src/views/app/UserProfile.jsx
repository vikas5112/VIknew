import React, { useState, useEffect } from "react";
import { useGetUserDetailsQuery } from "../../store/user/userApiSlice";
import { useGetInvitationsQuery } from "../../store/connection/connectionApiSlice";
import { useGetAllUsersQuery } from "../../store/user/userApiSlice";
import { useLikeCommentMutation } from "../../store/post/postApiSlice";
import { useGetConnectionQuery } from "../../store/connection/connectionApiSlice";
import { useSelector } from "react-redux";
import {
  Row,
  Col,
  Container,
  Dropdown,
  Nav,
  Tab,
  OverlayTrigger,
  Tooltip,
  Button,
  Modal,
} from "react-bootstrap";
import Card from "../../components/Card";
import CustomToggle from "../../components/Dropdowns";
import ShareOffcanvas from "../../components/ShareOffcanvas";
import TextEditor from "../../components/TextEditor";
import RenderFile from "../../components/RenderFile";
import FeedBlock from "../../components/FeedBlock";

import {
  useCreatePostMutation,
  useGetPostsForUserQuery,
  useFeedUploadMutation,
  useLikePostMutation,
  useCreateCommentMutation,
  useGetUrlMetaMutation
} from "../../store/post/postApiSlice";

import { Link } from "react-router-dom";
import FsLightbox from "fslightbox-react";

// images
import img1 from "../../assets/images/page-img/profile-bg1.jpg";
import bgImg from "../../assets/images/page-img/bg-Grey-img.jpg";
import img2 from "../../assets/images/user/11.png";
import img3 from "../../assets/images/icon/08.png";
import img4 from "../../assets/images/icon/09.png";
import img5 from "../../assets/images/icon/10.png";
import img6 from "../../assets/images/icon/11.png";
import img7 from "../../assets/images/icon/12.png";
import img8 from "../../assets/images/icon/13.png";
import img9 from "../../assets/images/page-img/07.jpg";
import img10 from "../../assets/images/page-img/06.jpg";
import user1 from "../../assets/images/user/1.jpg";
import user05 from "../../assets/images/user/05.jpg";
import user01 from "../../assets/images/user/01.jpg";
import user02 from "../../assets/images/user/02.jpg";
import user03 from "../../assets/images/user/03.jpg";
import user06 from "../../assets/images/user/06.jpg";
import user07 from "../../assets/images/user/07.jpg";
import user08 from "../../assets/images/user/08.jpg";
import user09 from "../../assets/images/user/09.jpg";
import user10 from "../../assets/images/user/10.jpg";
import user13 from "../../assets/images/user/13.jpg";
import user14 from "../../assets/images/user/14.jpg";
import user15 from "../../assets/images/user/15.jpg";
import user16 from "../../assets/images/user/16.jpg";
import user17 from "../../assets/images/user/17.jpg";
import user18 from "../../assets/images/user/18.jpg";
import user19 from "../../assets/images/user/19.jpg";
import p1 from "../../assets/images/page-img/p1.jpg";
import p3 from "../../assets/images/page-img/p3.jpg";
import icon1 from "../../assets/images/icon/01.png";
import icon2 from "../../assets/images/icon/02.png";
import icon3 from "../../assets/images/icon/03.png";
import icon4 from "../../assets/images/icon/04.png";
import icon5 from "../../assets/images/icon/05.png";
import icon6 from "../../assets/images/icon/06.png";
import icon7 from "../../assets/images/icon/07.png";
import g1 from "../../assets/images/page-img/g1.jpg";
import g2 from "../../assets/images/page-img/g2.jpg";
import g3 from "../../assets/images/page-img/g3.jpg";
import g4 from "../../assets/images/page-img/g4.jpg";
import g5 from "../../assets/images/page-img/g5.jpg";
import g6 from "../../assets/images/page-img/g6.jpg";
import g7 from "../../assets/images/page-img/g7.jpg";
import g8 from "../../assets/images/page-img/g8.jpg";
import g9 from "../../assets/images/page-img/g9.jpg";
import loader from "../../assets/images/page-img/page-load-loader.gif";
import small07 from "../../assets/images/small/07.png";
import small08 from "../../assets/images/small/08.png";
import small09 from "../../assets/images/small/09.png";
import small1 from "../../assets/images/small/07.png";
import small2 from "../../assets/images/small/08.png";
import small3 from "../../assets/images/small/09.png";
import small4 from "../../assets/images/small/10.png";
import small5 from "../../assets/images/small/11.png";
import small6 from "../../assets/images/small/12.png";
import small7 from "../../assets/images/small/13.png";
import small8 from "../../assets/images/small/14.png";
import user9 from "../../assets/images/user/1.jpg";
import img51 from "../../assets/images/page-img/51.jpg";
import img52 from "../../assets/images/page-img/52.jpg";
import img53 from "../../assets/images/page-img/53.jpg";
import img54 from "../../assets/images/page-img/54.jpg";
import img55 from "../../assets/images/page-img/55.jpg";
import img56 from "../../assets/images/page-img/56.jpg";
import img57 from "../../assets/images/page-img/57.jpg";
import img58 from "../../assets/images/page-img/58.jpg";
import img59 from "../../assets/images/page-img/59.jpg";
import img60 from "../../assets/images/page-img/60.jpg";
import img61 from "../../assets/images/page-img/61.jpg";
import img62 from "../../assets/images/page-img/62.jpg";
import img64 from "../../assets/images/page-img/64.jpg";
import img65 from "../../assets/images/page-img/65.jpg";
import img63 from "../../assets/images/page-img/63.jpg";
import backgroundImg from "../../assets/images/bg/bg.jpg";

const UserProfile = () => {
  const [allPosts, setAllPosts] = useState([]);
  const [show, setShow] = useState(false);
  const [details, setDetails] = useState({});
  const [post, setPost] = useState(0);
  const [textEditorData, setTextEditorData] = useState(null);
  const [urlDetails, setUrlDetails] = useState({});
  const [file, setFile] = useState(null);
  const [createPost] = useCreatePostMutation();
  const [commentPost] = useCreateCommentMutation();
  const [feedUpload] = useFeedUploadMutation();
  const [likePost] = useLikePostMutation();
  const getPost = useGetPostsForUserQuery();
  const [getUrlMeta] = useGetUrlMetaMutation();

  const handleClose = () => {
    setTextEditorData(null);
    setUrlDetails({})
    setFile(null)
    setShow(false);
  };
  const handleShow = () => setShow(true);

  const uploadMediaHandle = (fileData) => {
    setFile(fileData);
  };

  const fetchUrlDetails = async(url) => {
   const result = await getUrlMeta({
     url: url,
   });
   if(result?.data?.status === 1 && result?.data?.data){
     setUrlDetails(result?.data?.data)
   }
 };

  const handleSubmit = async () => {
    let multerData = new FormData();
    multerData.append("file", file);

    let payload;
    let url_meta_data={}
    if(urlDetails){
      url_meta_data={...urlDetails}
    }

    if (file) {
      const feedRes = await feedUpload(multerData);
      payload = {
        // plain_text: text,
        text_editor_data: textEditorData,
        file_id: feedRes?.data?.data?.data?._id,
        file_url: feedRes?.data?.data?.data?.file_url,
        file_type: file?.type,
      };
      if (feedRes?.data?.status === 1) {
      }
    } else {
      payload = {
        // plain_text: text,
        text_editor_data: textEditorData,
      };
    }
    const result = await createPost({...payload,url_meta_data:url_meta_data});
    if (result?.data?.status === 1) {
      getPost.refetch();
      setFile(null);
      handleClose();
    }
  };
  const handleLike = async (id) => {
    const result = await likePost({
      post_id: id,
    });
    // console.log(result?.data?.status, "ress", result?.data?.data);
  };

  const handleComment = async (id, comment) => {
    const result = await commentPost({
      post_id: id,
      comment_text: comment,
      parent_comment: "",
    });
    if (result?.data?.status === 1) {
      getPost.refetch();
    }
  };

  const userInfo = useSelector((state) => state.user.userDetails);
  console.log(userInfo);
  //   const connection_count = useSelector((state) => state.connection);
  //     console.log('aps',connection_count)

  const [imageController, setImageController] = useState({
    toggler: false,
    slide: 1,
  });
  const { data: detailData } = useGetUserDetailsQuery(null);
  const { data: connectionData } = useGetConnectionQuery(null);
  //   console.log(connectionData)
  // console.log(useGetConnectionQuery());
  const { postData } = useGetPostsForUserQuery(null);

  //invitation
  const [allInvitations, setAllInvitations] = useState([]);
  const [allConnections, setAllConnections] = useState([]);
  const [likeComment] = useLikeCommentMutation();
  const { data } = useGetInvitationsQuery();

  //   console.log(data)
  useEffect(() => {
    if (getPost?.data?.status === 1 && Array.isArray(getPost?.data?.data) && getPost?.data?.data.length>0) {
      setAllPosts(getPost?.data?.data);
    }
  }, [getPost?.data]);

  useEffect(() => {
    if (data && data?.status === 1 && data?.data?.data?.length > 0) {
      setAllInvitations(data?.data?.data);
    }
  }, [data]);

  useEffect(() => {
    if (connectionData) {
      setAllConnections(connectionData.data);
    }
  }, [connectionData]);

  // console.log(allConnections)

  useEffect(() => {
    if (detailData) {
      setDetails(detailData.data[0]);
    }
  }, [detailData]);

  useEffect(() => {
    if (postData) {
      setPost(postData.Object.keys(data)?.length);
    }
  });
  const handleReply = async (comment_id, post_id, text) => {
    const result = await commentPost({
      parent_comment: comment_id,
      post_id: post_id,
      comment_text: text,
    });
    if (result?.data?.status === 1) {
      getPost.refetch();
    }
  };
  const handleCommentLike = async (post_id, comment_id) => {
    const result = await likeComment({
      post_id: post_id,
      comment_id: comment_id,
    });
    // console.log(result?.data?.status, "ress", result?.data?.data);
  };

  function imageOnSlide(number) {
    setImageController({
      toggler: !imageController.toggler,
      slide: number,
    });
  }
console.log("posts",allPosts)
  return (
    <>
      <FsLightbox
        toggler={imageController.toggler}
        sources={[
          g1,
          g2,
          g3,
          g4,
          g5,
          g6,
          g7,
          g8,
          g9,
          img51,
          img52,
          img53,
          img54,
          img55,
          img56,
          img57,
          img58,
          img59,
          img60,
          img61,
          img62,
          img63,
          img64,
          img65,
          img51,
          img52,
          img53,
          img54,
          img55,
          img56,
          img57,
          img58,
          img51,
          img52,
          img53,
          img54,
          img55,
          img56,
          img57,
          img58,
          img59,
          img60,
        ]}
        slide={imageController.slide}
      />
      <Container>
        <Row>
          <Col sm={12}>
            <Card>
              <Card.Body className=" profile-page p-0">
                <div className="profile-header">
                  <div className="position-relative">
                    <img
                    style={{height:"350px",width:"100%"}}
                      loading="lazy"
                      src={userInfo?.backgournd_picture || img1}
                      alt="profile-bg"
                      className="rounded img-fluid"
                    />
                    <ul className="header-nav list-inline d-flex flex-wrap justify-end p-0 m-0">
                      {/* <li onClick={console.log("sd")}>
                                    <Link to="/dashboard/app/user-profile-edit" className="material-symbols-outlined">
                                       edit
                                    </Link>
                                    </li> */}
                      {/* <li>
                                    <Link to="#" className="material-symbols-outlined">
                                    settings
                                    </Link>
                                 </li> */}
                    </ul>
                  </div>
                  <div className="user-detail text-center mb-3">
                    <div className="profile-img">
                      <img style={{width:"130px",height:"130px"}}
                        loading="lazy"
                        src={
                          userInfo?.profile_picture ||
                          "https://jbpbucket-dev.s3.amazonaws.com/devjanbask/profile_pic/f65d1d56-5887-4abb-b4f1-a3100975g718.jpg"
                        }
                        alt="profile-img1"
                        className="avatar-130 img-fluid"
                      />
                    </div>
                    <div className="profile-detail">
                      <h3>
                        {userInfo?.first_name + " " + userInfo?.last_name}
                      </h3>
                    </div>
                  </div>
                  <div className="profile-info p-3 d-flex align-items-center justify-content-between position-relative">
                    {/* <div className="social-links">
                                 <ul className="social-data-block d-flex align-items-center justify-content-between list-inline p-0 m-0">
                                    <li className="text-center pe-3">
                                       <Link to="#"><img loading="lazy" src={img3} className="img-fluid rounded" alt="facebook"/></Link>
                                    </li>
                                    <li className="text-center pe-3">
                                       <Link to="#"><img loading="lazy" src={img4} className="img-fluid rounded" alt="Twitter"/></Link>
                                    </li>
                                    <li className="text-center pe-3">
                                       <Link to="#"><img loading="lazy" src={img5} className="img-fluid rounded" alt="Instagram"/></Link>
                                    </li>
                                    <li className="text-center pe-3">
                                       <Link to="#"><img loading="lazy" src={img6} className="img-fluid rounded" alt="Google plus"/></Link>
                                    </li>
                                    <li className="text-center pe-3">
                                       <Link to="#"><img loading="lazy" src={img7} className="img-fluid rounded" alt="You tube"/></Link>
                                    </li>
                                    <li className="text-center md-pe-3 pe-0">
                                       <Link to="#"><img loading="lazy" src={img8} className="img-fluid rounded" alt="linkedin"/></Link>
                                    </li>
                                 </ul>
                              </div> */}
                    <div className="social-info">
                      <ul className="social-data-block d-flex align-items-center justify-content-between list-inline p-0 m-0">
                        <li className="text-center ps-3">
                          <h6>Posts</h6>
                          <p className="mb-0">{post}</p>
                        </li>
                        <li className="text-center ps-3">
                          <h6>Connections</h6>
                          <p className="mb-0">{userInfo?.connection_count}</p>
                        </li>
                        <li className="text-center ps-3">
                          <h6>Invitations</h6>
                          <p className="mb-0">{userInfo?.invitation_count}</p>
                        </li>
                      </ul>
                    </div>
                    {/* <div className="position-relative">
                      <ul className="header-nav list-inline d-flex flex-wrap justify-end p-0 m-0">
                        <li>
                          <Link
                            to="/dashboard/app/user-profile-edit"
                            className="material-symbols-outlined"
                          >
                            edit
                          </Link>
                        </li> */}
                    {/* <li>
                                    <Link to="#" className="material-symbols-outlined">
                                    settings
                                    </Link>
                                 </li> */}
                    {/* </ul>
                    </div> */}
                  </div>
                </div>
              </Card.Body>
            </Card>
          </Col>
          <Tab.Container id="left-tabs-example" defaultActiveKey="first">
            <Card className="p-0">
              <Card.Body className="p-0">
                <div className="user-tabing">
                  <Nav
                    as="ul"
                    variant="pills"
                    className="d-flex align-items-center justify-content-center profile-feed-items p-0 m-0"
                  >
                    <Nav.Item as="li" className=" col-12 col-sm-3 p-0 ">
                      <Nav.Link
                        href="#pills-timeline-tab"
                        eventKey="first"
                        role="button"
                        // style={{ backgroundColor: "#1F639C" }}
                        className=" text-center timeline-btn  p-3"
                      >
                        Timeline
                      </Nav.Link>
                    </Nav.Item>
                    <Nav.Item as="li" className="col-12 col-sm-3 p-0">
                      <Nav.Link
                        href="#pills-about-tab"
                        eventKey="second"
                        role="button"
                        className="text-center p-3"
                      >
                        About
                      </Nav.Link>
                    </Nav.Item>
                    {/* <Nav.Item as="li" className=" col-12 col-sm-3 p-0">
                                 <Nav.Link  href="#pills-friends-tab"  eventKey="third" role="button" className="text-center p-3">Friends</Nav.Link>
                              </Nav.Item>
                              <Nav.Item as="li" className="col-12 col-sm-3 p-0">
                                 <Nav.Link  href="#pills-photos-tab"  eventKey="forth" role="button" className="text-center p-3">Photos</Nav.Link>
                              </Nav.Item> */}
                  </Nav>
                </div>
              </Card.Body>
            </Card>
            <Col sm={12}>
              <Tab.Content>
                <Tab.Pane eventKey="first">
                  <Card.Body className=" p-0">
                    <Row>
                      <Col lg={4}>
                        {/* <Card>
                                       <Card.Body>
                                          <Link to="#"><span className="badge badge-pill bg-primary font-weight-normal ms-auto me-1  material-symbols-outlined md-14">grade</span> 27 Items for yoou</Link>
                                       </Card.Body>
                                    </Card> */}
                        {/* <Card>
                                       <div className="card-header d-flex justify-content-between">
                                          <div className="header-title">
                                             <h4 className="card-title">Life Event</h4>
                                          </div>
                                          <div className="card-header-toolbar d-flex align-items-center">
                                             <p className="m-0"><Link to="#"> Create </Link></p>
                                          </div>
                                       </div>
                                       <Card.Body >
                                          <Row>
                                             <Col sm={12}>
                                                <div className="event-post position-relative">
                                                   <Link to="#"><img loading="lazy" src={img9} alt="gallary1" className="img-fluid rounded"/></Link>
                                                   <div className="job-icon-position">
                                                   <div className="job-icon bg-primary p-2 d-inline-block rounded-circle material-symbols-outlined text-white">
                                                      local_mall
                                                   </div>
                                                   </div>
                                                   <div className="card-body text-center p-2">
                                                      <h5>Started New Job at Apple</h5>
                                                      <p>January 24, 2019</p>
                                                   </div>
                                                </div>
                                             </Col>
                                             <Col sm={12}>
                                                <div className="event-post position-relative">
                                                   <Link to="#"><img loading="lazy" src={img10} alt="gallary1" className="img-fluid rounded"/></Link>
                                                   <div className="job-icon-position">
                                                   <div className="job-icon bg-primary p-2 d-inline-block rounded-circle material-symbols-outlined text-white">
                                                      local_mall
                                                   </div>
                                                   </div>
                                                   <div className="card-body text-center p-2">
                                                      <h5>Freelance Photographer</h5>
                                                      <p className="mb-0">January 24, 2019</p>
                                                   </div>
                                                </div>
                                             </Col>
                                          </Row>
                                       </Card.Body>
                                    </Card> */}
                        {/* <Card>
                                       <div className="card-header d-flex justify-content-between">
                                          <div className="header-title">
                                             <h4 className="card-title">Photos</h4>
                                          </div>
                                          <div className="card-header-toolbar d-flex align-items-center">
                                             <p className="m-0"><Link to="#">Add Photo </Link></p>
                                          </div>
                                       </div>
                                       <Card.Body>
                                          <ul className="profile-img-gallary p-0 m-0 list-unstyled">
                                             <li><Link onClick={() => imageOnSlide(1)} to="#"><img loading="lazy" src={g1} alt="gallary" className="img-fluid" /></Link></li>
                                             <li><Link onClick={() => imageOnSlide(2)} to="#"><img loading="lazy" src={g2} alt="gallary" className="img-fluid" /></Link></li>
                                             <li><Link onClick={() => imageOnSlide(3)} to="#"><img loading="lazy" src={g3} alt="gallary" className="img-fluid" /></Link></li>
                                             <li><Link onClick={() => imageOnSlide(4)} to="#"><img loading="lazy" src={g4} alt="gallary" className="img-fluid" /></Link></li>
                                             <li><Link onClick={() => imageOnSlide(5)} to="#"><img loading="lazy" src={g5} alt="gallary" className="img-fluid" /></Link></li>
                                             <li><Link onClick={() => imageOnSlide(6)} to="#"><img loading="lazy" src={g6} alt="gallary" className="img-fluid" /></Link></li>
                                             <li><Link onClick={() => imageOnSlide(7)} to="#"><img loading="lazy" src={g7} alt="gallary" className="img-fluid" /></Link></li>
                                             <li><Link onClick={() => imageOnSlide(8)} to="#"><img loading="lazy" src={g8} alt="gallary" className="img-fluid" /></Link></li>
                                             <li><Link onClick={() => imageOnSlide(9)} to="#"><img loading="lazy" src={g9} alt="gallary" className="img-fluid" /></Link></li>
                                          </ul>
                                       </Card.Body>
                                    </Card> */}
                        <Card>
                          <div className="card-header d-flex justify-content-between">
                            <div className="header-title">
                              <h4 className="card-title">
                                Connections ({userInfo?.connection_count})
                              </h4>
                            </div>
                            {/* <div className="card-header-toolbar d-flex align-items-center">
                                             <p className="m-0"><Link to="javacsript:void();">Add New </Link></p>
                                          </div> */}
                          </div>
                          <Card.Body>
                            <ul className="profile-img-gallary p-0 m-0 list-unstyled">
                              {allConnections?.map((e) => (
                                <li>
                                  <Link to="#">
                                    <img
                                      loading="lazy"
                                      src={user05}
                                      alt="gallary"
                                      className="img-fluid"
                                    />
                                  </Link>
                                  <h6 className="mt-2 text-center">
                                    {e.requester.username}{" "}
                                  </h6>
                                </li>
                              ))}

                              {/* <li>
                                <Link to="#">
                                  <img
                                    loading="lazy"
                                    src={user06}
                                    alt="gallary"
                                    className="img-fluid"
                                  />
                                </Link>
                                <h6 className="mt-2 text-center">Tara Zona</h6>
                              </li>
                              <li>
                                <Link to="#">
                                  <img
                                    loading="lazy"
                                    src={user07}
                                    alt="gallary"
                                    className="img-fluid"
                                  />
                                </Link>
                                <h6 className="mt-2 text-center">Polly Tech</h6>
                              </li>
                              <li>
                                <Link to="#">
                                  <img
                                    loading="lazy"
                                    src={user08}
                                    alt="gallary"
                                    className="img-fluid"
                                  />
                                </Link>
                                <h6 className="mt-2 text-center">Bill Emia</h6>
                              </li>
                              <li>
                                <Link to="#">
                                  <img
                                    loading="lazy"
                                    src={user09}
                                    alt="gallary"
                                    className="img-fluid"
                                  />
                                </Link>
                                <h6 className="mt-2 text-center">Moe Fugga</h6>
                              </li>
                              <li>
                                <Link to="#">
                                  <img
                                    loading="lazy"
                                    src={user10}
                                    alt="gallary"
                                    className="img-fluid"
                                  />
                                </Link>
                                <h6 className="mt-2 text-center">
                                  Hal Appeno{" "}
                                </h6>
                              </li>
                              <li>
                                <Link to="#">
                                  <img
                                    loading="lazy"
                                    src={user07}
                                    alt="gallary"
                                    className="img-fluid"
                                  />
                                </Link>
                                <h6 className="mt-2 text-center">Zack Lee</h6>
                              </li>
                              <li>
                                <Link to="#">
                                  <img
                                    loading="lazy"
                                    src={user06}
                                    alt="gallary"
                                    className="img-fluid"
                                  />
                                </Link>
                                <h6 className="mt-2 text-center">Terry Aki</h6>
                              </li>
                              <li>
                                <Link to="#">
                                  <img
                                    loading="lazy"
                                    src={user05}
                                    alt="gallary"
                                    className="img-fluid"
                                  />
                                </Link>
                                <h6 className="mt-2 text-center">Greta Life</h6>
                              </li> */}
                            </ul>
                          </Card.Body>
                        </Card>
                      </Col>
                      <Col lg={8}>
                        <Card id="post-modal-data">
                          <div className="card-header d-flex justify-content-between">
                            <div className="header-title">
                              <h4 className="card-title">Create Post</h4>
                            </div>
                          </div>
                          <Card.Body>
                            <div className="d-flex align-items-center">
                              <div className="user-img">
                                <img
                                  loading="lazy"
                                  src={
                                    userInfo?.profile_picture ||
                                    "https://jbpbucket-dev.s3.amazonaws.com/devjanbask/profile_pic/f65d1d56-5887-4abb-b4f1-a3100975g718.jpg"
                                  }
                                  alt="userimg"
                                  className="avatar-60 rounded-circle"
                                />
                              </div>
                              <form
                                className="post-text ms-3 w-100 "
                                onClick={handleShow}
                              >
                                <input
                                  type="text"
                                  className="form-control rounded"
                                  placeholder="Write something here..."
                                  style={{ border: "none" }}
                                />
                              </form>
                            </div>
                            <hr />
                          </Card.Body>
                          <Modal show={show} onHide={handleClose} size="lg">
                            <Modal.Header className="d-flex justify-content-between">
                              <h5 className="modal-title" id="post-modalLabel">
                                Create Post
                              </h5>
                              <button
                                type="button"
                                className="btn btn-secondary lh-1"
                                onClick={handleClose}
                              >
                                <span className="material-symbols-outlined">
                                  close
                                </span>
                              </button>
                            </Modal.Header>
                            <Modal.Body>
                              <div className="d-flex align-items-center">
                                <div className="user-img">
                                  <img
                                    loading="lazy"
                                    src={
                                      userInfo?.profile_picture ||
                                      "https://jbpbucket-dev.s3.amazonaws.com/devjanbask/profile_pic/f65d1d56-5887-4abb-b4f1-a3100975g718.jpg"
                                    }
                                    alt="userimg"
                                    className="avatar-60 rounded-circle img-fluid"
                                  />
                                </div>
                                <form
                                  className="post-text ms-3 w-100"
                                  action=""
                                >
                                  <TextEditor
                                    textEditorData={textEditorData}
                                    onChange={setTextEditorData}

                                     urlDetails={urlDetails}
                                     fetchUrlDetails={fetchUrlDetails}
                                  />
                                </form>
                              </div>
                              <hr />
                              <ul className="d-flex flex-wrap align-items-center list-inline m-0 p-0">
                                <li className="col-md-6 mb-3">
                                  <div className="bg-soft-primary rounded p-2 pointer me-3">
                                    <label className="shareOption">
                                      <span>Photo/Video</span>

                                      <input
                                        style={{ display: "none" }}
                                        type="file"
                                        id="file"
                                        //  accept=".png,.jpeg,.jpg"
                                        onChange={(e) => {
                                          uploadMediaHandle(e.target.files[0]);
                                        }}
                                      />
                                    </label>
                                  </div>
                                </li>
                                <RenderFile file={file} filetype={"filetype"} />
                              </ul>
                              <hr />
                              <Button
                                variant="primary"
                                className="d-block w-100 mt-3"
                                onClick={handleSubmit}
                              >
                                Post
                              </Button>
                            </Modal.Body>
                          </Modal>
                        </Card>
                        <Card>
                          {allPosts?.map((val) => (
                            <FeedBlock
                              postDetails={val}
                              handleLike={handleLike}
                              handleReply={handleReply}
                              handleCommentLike={handleCommentLike}
                              handleComment={handleComment}
                              getPost={getPost}
                            />
                          ))}
                        </Card>
                      </Col>
                    </Row>
                  </Card.Body>
                </Tab.Pane>
                <Tab.Pane eventKey="second">
                  <Tab.Container
                    id="left-tabs-example"
                    defaultActiveKey="about1"
                  >
                    <Row>
                      {/* <Col md={4}>
                                    <Card>
                                       <Card.Body>
                                          <Nav variant="pills"  className=" basic-info-items list-inline d-block p-0 m-0">
                                             <Nav.Item >
                                                <Nav.Link href="#" eventKey="about1">Contact and Basic Info</Nav.Link>
                                             </Nav.Item>
                                             <Nav.Item >
                                                <Nav.Link href="#" eventKey="about2">Hobbies and Interests</Nav.Link>
                                             </Nav.Item>
                                             <Nav.Item >
                                                <Nav.Link href="#" eventKey="about3">Family and Relationship</Nav.Link>
                                             </Nav.Item>
                                             <Nav.Item >
                                                <Nav.Link href="#" eventKey="about4">Work and Education</Nav.Link>
                                             </Nav.Item>
                                             <Nav.Item >
                                                <Nav.Link href="#" eventKey="about5">Places You've Lived</Nav.Link>
                                             </Nav.Item>
                                          </Nav>
                                       </Card.Body>
                                    </Card>
                                 </Col> */}
                      <Col md={12} className=" ps-4">
                        <Card>
                          <Card.Body>
                            <Tab.Content>
                              <Tab.Pane eventKey="about1">
                                <h4>Personal Info</h4>
                                <hr />
                                <Row className="mb-2">
                                  <div className="col-3">
                                    <h6>First name : </h6>
                                  </div>
                                  <div className="col-3">
                                    <p className="mb-0">
                                      {userInfo.first_name}
                                    </p>
                                  </div>
                                  <div className="col-3">
                                    <h6>Last name : </h6>
                                  </div>
                                  <div className="col-3">
                                    <p className="mb-0">{userInfo.last_name}</p>
                                  </div>
                                </Row>
                                {details?.first_name && (
                                  <Row className="mb-2">
                                    <div className="col-3">
                                      <h6>UserName:</h6>
                                    </div>
                                    <div className="col-3">
                                      <p className="mb-0">
                                        {userInfo?.first_name +
                                          " " +
                                          userInfo?.last_name}
                                      </p>
                                    </div>
                                    <div className="col-3">
                                      <h6>Email:</h6>
                                    </div>
                                    <div className="col-3">
                                      <p className="mb-0">{userInfo?.email}</p>
                                    </div>
                                  </Row>
                                )}
                                {userInfo?.user_type && (
                                  <Row className="mb-2">
                                    <div className="col-3">
                                      <h6>Usertype</h6>
                                    </div>
                                    <div className="col-3">
                                      <p className="mb-0">
                                        {userInfo?.user_type}
                                      </p>
                                    </div>
                                    <div className="col-3">
                                      <h6>Phone Number:</h6>
                                    </div>
                                    <div className="col-3">
                                      <p className="mb-0">{userInfo?.phone}</p>
                                    </div>
                                  </Row>
                                )}
                                
                              </Tab.Pane>
                              <Tab.Pane eventKey="about2">
                                <h4 className="mt-2">Hobbies and Interests</h4>
                                <hr />
                                <h6 className="mb-1">Hobbies:</h6>
                                <p>
                                  Hi, I’m Bni, I’m 26 and I work as a Web
                                  Designer for the iqonicdesign.I like to ride
                                  the bike to work, swimming, and working out. I
                                  also like reading design magazines, go to
                                  museums, and binge watching a good tv show
                                  while it’s raining outside.
                                </p>
                                <h6 className="mt-2 mb-1">
                                  Favourite TV Shows:
                                </h6>
                                <p>
                                  Breaking Good, RedDevil, People of Interest,
                                  The Running Dead, Found, American Guy.
                                </p>
                                <h6 className="mt-2 mb-1">Favourite Movies:</h6>
                                <p>
                                  Idiocratic, The Scarred Wizard and the Fire
                                  Crown, Crime Squad, Ferrum Man.
                                </p>
                                <h6 className="mt-2 mb-1">Favourite Games:</h6>
                                <p>
                                  The First of Us, Assassin’s Squad, Dark
                                  Assylum, NMAK16, Last Cause 4, Grand Snatch
                                  Auto.
                                </p>
                                <h6 className="mt-2 mb-1">
                                  Favourite Music Bands / Artists:
                                </h6>
                                <p>
                                  Iron Maid, DC/AC, Megablow, The Ill, Kung
                                  Fighters, System of a Revenge.
                                </p>
                                <h6 className="mt-2 mb-1">Favourite Books:</h6>
                                <p>
                                  The Crime of the Century, Egiptian Mythology
                                  101, The Scarred Wizard, Lord of the Wings,
                                  Amongst Gods, The Oracle, A Tale of Air and
                                  Water.
                                </p>
                                <h6 className="mt-2 mb-1">
                                  Favourite Writers:
                                </h6>
                                <p>
                                  Martin T. Georgeston, Jhonathan R. Token,
                                  Ivana Rowle, Alexandria Platt, Marcus Roth.
                                </p>
                              </Tab.Pane>
                              <Tab.Pane eventKey="about3">
                                <h4 className="mb-3">Relationship</h4>
                                <ul className="suggestions-lists m-0 p-0">
                                  <li className="d-flex mb-4 align-items-center">
                                    <div className="user-img img-fluid">
                                      <span className="material-symbols-outlined md-18">
                                        add
                                      </span>
                                    </div>
                                    <div className="media-support-info ms-3">
                                      <h6>Add Your Relationship Status</h6>
                                    </div>
                                  </li>
                                </ul>
                                <h4 className="mt-3 mb-3">Family Members</h4>
                                <ul className="suggestions-lists m-0 p-0">
                                  <li className="d-flex mb-4 align-items-center">
                                    <div className="user-img img-fluid">
                                      <span className="material-symbols-outlined md-18">
                                        add
                                      </span>
                                    </div>
                                    <div className="media-support-info ms-3">
                                      <h6>Add Family Members</h6>
                                    </div>
                                  </li>
                                  <li className="d-flex mb-4 align-items-center justify-content-between">
                                    <div className="user-img img-fluid">
                                      <img
                                        loading="lazy"
                                        src={user01}
                                        alt="story1"
                                        className="rounded-circle avatar-40"
                                      />
                                    </div>
                                    <div className="w-100">
                                      <div className="d-flex justify-content-between">
                                        <div className="ms-3">
                                          <h6>Paul Molive</h6>
                                          <p className="mb-0">Brothe</p>
                                        </div>
                                        <div className="edit-relation">
                                          <Link to="#">
                                            <span className="material-symbols-outlined me-2 md-18">
                                              edit
                                            </span>
                                            Edit
                                          </Link>
                                        </div>
                                      </div>
                                    </div>
                                  </li>
                                  <li className="d-flex justify-content-between mb-4  align-items-center">
                                    <div className="user-img img-fluid">
                                      <img
                                        loading="lazy"
                                        src={user02}
                                        alt="story-img"
                                        className="rounded-circle avatar-40"
                                      />
                                    </div>
                                    <div className="w-100">
                                      <div className="d-flex flex-wrap justify-content-between">
                                        <div className=" ms-3">
                                          <h6>Anna Mull</h6>
                                          <p className="mb-0">Sister</p>
                                        </div>
                                        <div className="edit-relation">
                                          <Link to="#">
                                            <span className="material-symbols-outlined me-2 md-18">
                                              edit
                                            </span>
                                            Edit
                                          </Link>
                                        </div>
                                      </div>
                                    </div>
                                  </li>
                                  <li className="d-flex mb-4 align-items-center justify-content-between">
                                    <div className="user-img img-fluid">
                                      <img
                                        loading="lazy"
                                        src={user03}
                                        alt="story-img"
                                        className="rounded-circle avatar-40"
                                      />
                                    </div>
                                    <div className="w-100">
                                      <div className="d-flex justify-content-between">
                                        <div className="ms-3">
                                          <h6>Paige Turner</h6>
                                          <p className="mb-0">Cousin</p>
                                        </div>
                                        <div className="edit-relation">
                                          <Link to="#">
                                            <span className="material-symbols-outlined me-2 md-18">
                                              edit
                                            </span>
                                            Edit
                                          </Link>
                                        </div>
                                      </div>
                                    </div>
                                  </li>
                                </ul>
                              </Tab.Pane>
                              <Tab.Pane eventKey="about4">
                                <h4 className="mb-3">Work</h4>
                                <ul className="suggestions-lists m-0 p-0">
                                  <li className="d-flex justify-content-between mb-4  align-items-center">
                                    <div className="user-img img-fluid">
                                      <span className="material-symbols-outlined md-18">
                                        add
                                      </span>
                                    </div>
                                    <div className="ms-3">
                                      <h6>Add Work Place</h6>
                                    </div>
                                  </li>
                                  <li className="d-flex mb-4 align-items-center justify-content-between">
                                    <div className="user-img img-fluid">
                                      <img
                                        loading="lazy"
                                        src={user01}
                                        alt="story-img"
                                        className="rounded-circle avatar-40"
                                      />
                                    </div>
                                    <div className="w-100">
                                      <div className="d-flex justify-content-between">
                                        <div className="ms-3">
                                          <h6>Themeforest</h6>
                                          <p className="mb-0">Web Designer</p>
                                        </div>
                                        <div className="edit-relation">
                                          <Link
                                            to="#"
                                            className="d-flex align-items-center"
                                          >
                                            <span className="material-symbols-outlined me-2 md-18">
                                              edit
                                            </span>
                                            Edit
                                          </Link>
                                        </div>
                                      </div>
                                    </div>
                                  </li>
                                  <li className="d-flex mb-4 align-items-center justify-content-between">
                                    <div className="user-img img-fluid">
                                      <img
                                        loading="lazy"
                                        src={user02}
                                        alt="story-img"
                                        className="rounded-circle avatar-40"
                                      />
                                    </div>
                                    <div className="w-100">
                                      <div className="d-flex flex-wrap justify-content-between">
                                        <div className="ms-3">
                                          <h6>iqonicdesign</h6>
                                          <p className="mb-0">Web Developer</p>
                                        </div>
                                        <div className="edit-relation">
                                          <Link
                                            to="#"
                                            className="d-flex align-items-center"
                                          >
                                            <span className="material-symbols-outlined me-2 md-18">
                                              edit
                                            </span>
                                            Edit
                                          </Link>
                                        </div>
                                      </div>
                                    </div>
                                  </li>
                                  <li className="d-flex mb-4 align-items-center justify-content-between">
                                    <div className="user-img img-fluid">
                                      <img
                                        loading="lazy"
                                        src={user03}
                                        alt="story-img"
                                        className="rounded-circle avatar-40"
                                      />
                                    </div>
                                    <div className="w-100">
                                      <div className="d-flex flex-wrap justify-content-between">
                                        <div className="ms-3">
                                          <h6>W3school</h6>
                                          <p className="mb-0">Designer</p>
                                        </div>
                                        <div className="edit-relation">
                                          <Link
                                            to="#"
                                            className="d-flex align-items-center"
                                          >
                                            <span className="material-symbols-outlined me-2 md-18">
                                              edit
                                            </span>
                                            Edit
                                          </Link>
                                        </div>
                                      </div>
                                    </div>
                                  </li>
                                </ul>
                                <h4 className="mb-3">Professional Skills</h4>
                                <ul className="suggestions-lists m-0 p-0">
                                  <li className="d-flex mb-4 align-items-center">
                                    <div className="user-img img-fluid">
                                      <span className="material-symbols-outlined md-18">
                                        add
                                      </span>
                                    </div>
                                    <div className="ms-3">
                                      <h6>Add Professional Skills</h6>
                                    </div>
                                  </li>
                                </ul>
                                <h4 className="mt-3 mb-3">College</h4>
                                <ul className="suggestions-lists m-0 p-0">
                                  <li className="d-flex mb-4 align-items-center">
                                    <div className="user-img img-fluid">
                                      <span className="material-symbols-outlined md-18">
                                        add
                                      </span>
                                    </div>
                                    <div className="ms-3">
                                      <h6>Add College</h6>
                                    </div>
                                  </li>
                                  <li className="d-flex mb-4 align-items-center">
                                    <div className="user-img img-fluid">
                                      <img
                                        loading="lazy"
                                        src={user01}
                                        alt="story-img"
                                        className="rounded-circle avatar-40"
                                      />
                                    </div>
                                    <div className="w-100">
                                      <div className="d-flex flex-wrap justify-content-between">
                                        <div className="ms-3">
                                          <h6>Lorem ipsum</h6>
                                          <p className="mb-0">USA</p>
                                        </div>
                                        <div className="edit-relation">
                                          <Link
                                            to="#"
                                            className="d-flex align-items-center"
                                          >
                                            <span className="material-symbols-outlined me-2 md-18">
                                              edit
                                            </span>
                                            Edit
                                          </Link>
                                        </div>
                                      </div>
                                    </div>
                                  </li>
                                </ul>
                              </Tab.Pane>
                              <Tab.Pane eventKey="about5">
                                <h4 className="mb-3">
                                  Current City and Hometown
                                </h4>
                                <ul className="suggestions-lists m-0 p-0">
                                  <li className="d-flex mb-4 align-items-center justify-content-between">
                                    <div className="user-img img-fluid">
                                      <img
                                        loading="lazy"
                                        src={user01}
                                        alt="story-img"
                                        className="rounded-circle avatar-40"
                                      />
                                    </div>
                                    <div className="w-100">
                                      <div className="d-flex flex-wrap justify-content-between">
                                        <div className="ms-3">
                                          <h6>Georgia</h6>
                                          <p className="mb-0">Georgia State</p>
                                        </div>
                                        <div className="edit-relation">
                                          <Link
                                            to="#"
                                            className="d-flex align-items-center"
                                          >
                                            <span className="material-symbols-outlined me-2 md-18">
                                              edit
                                            </span>
                                            Edit
                                          </Link>
                                        </div>
                                      </div>
                                    </div>
                                  </li>
                                  <li className="d-flex mb-4 align-items-center justify-content-between">
                                    <div className="user-img img-fluid">
                                      <img
                                        loading="lazy"
                                        src={user02}
                                        alt="story-img"
                                        className="rounded-circle avatar-40"
                                      />
                                    </div>
                                    <div className="w-100">
                                      <div className="d-flex flex-wrap justify-content-between">
                                        <div className="ms-3">
                                          <h6>Atlanta</h6>
                                          <p className="mb-0">Atlanta City</p>
                                        </div>
                                        <div className="edit-relation">
                                          <Link
                                            to="#"
                                            className="d-flex align-items-center"
                                          >
                                            <span className="material-symbols-outlined me-2 md-18">
                                              edit
                                            </span>
                                            Edit
                                          </Link>
                                        </div>
                                      </div>
                                    </div>
                                  </li>
                                </ul>
                                <h4 className="mt-3 mb-3">
                                  Other Places Lived
                                </h4>
                                <ul className="suggestions-lists m-0 p-0">
                                  <li className="d-flex mb-4 align-items-center">
                                    <div className="user-img img-fluid">
                                      <span className="material-symbols-outlined md-18">
                                        add
                                      </span>
                                    </div>
                                    <div className="ms-3">
                                      <h6>Add Place</h6>
                                    </div>
                                  </li>
                                </ul>
                              </Tab.Pane>
                            </Tab.Content>
                          </Card.Body>
                        </Card>
                      </Col>
                    </Row>
                  </Tab.Container>
                </Tab.Pane>
                
              </Tab.Content>
            </Col>
          </Tab.Container>
        </Row>
      </Container>
    </>
  );
};

export default UserProfile;
