import React, { useState } from "react";
import {
  Row,
  Col,
  Container,
  Form,
  Button,
  Image,
  Alert,
} from "react-bootstrap";
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";
import { setUser } from "../../store/user/action";
import { useSelector, useDispatch } from "react-redux";
import "./index.scss";

//swiper
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Navigation, Autoplay } from "swiper";

// Import Swiper styles
import "swiper/swiper-bundle.min.css";
import "swiper/components/navigation/navigation.scss";

//img
import logo from "../../assets/images/main_logo.webp";
import login1 from "../../assets/images/slider1.jpg";
import login2 from "../../assets/images/slider2.jpg";
import login3 from "../../assets/images/slider3.jpg";
import { validation } from "./FormValidation";
import { useRecoveryPasswordMutation } from "../../store/user/userApiSlice";

// install Swiper modules

SwiperCore.use([Navigation, Autoplay]);

const Recoverypw = () => {
  const [formErrors, setFormErrors] = useState({});
  const [visiblePassword, setVisiblePassword] = useState(false);
  const [visibleConfirmPassword, setVisibleConfirmPassword] = useState(false);

  const [userInput, setUserInput] = useState({
    email: "",
    new_password: "",
    confirm_password: "",
    otp: "",
  });
  const [isValid, setIsValid] = useState({
    call: false,
    success: false,
    msg: "bbbb",
  });
  const user = useSelector((state) => state.user);
  let history = useHistory();
  const dispatch = useDispatch();
  const [recoveryPassword] = useRecoveryPasswordMutation();

  const handlUserInput = (e) => {
    const { name, value } = e.target;
    setUserInput({ ...userInput, [name]: value });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    event.stopPropagation();
    setFormErrors(validation(userInput));
    console.log("submit");

    dispatch(setUser("data"));
    if (Object.keys(validation(userInput)).length === 0) {
      const res = await recoveryPassword(userInput);

      console.log("res", res);
      const data = res?.data;
      if (res?.data?.status === 1) {
        setIsValid({
          ...isValid,
          call: true,
          success: true,
          msg: data?.message,
        });
        history.push("/auth/sign-in");
        validation("clear error");
      } else {
        if (res?.error?.status === 500) {
          setIsValid({
            ...isValid,
            call: true,
            success: false,
            msg: res?.error?.data.message.data || res?.error?.data.message,
          });
        } else {
          res.json().then((data) => {
            setIsValid({
              ...isValid,
              call: true,
              success: false,
              msg: res?.data?.message,
            });
            // console.log(error);;
          });
        }
      }

      validation("clear error");
    }
  };
  console.log("confirmMail", isValid);
  const handleVisible = (value) => {
    if (value === "password") {
      setVisiblePassword(!visiblePassword);
    }
    if (value === "confirm_password") {
      setVisibleConfirmPassword(!visibleConfirmPassword);
    }
  };
  return (
    <>
      <section className="sign-in-page">
        {/* <div id="container-inside">
          <div id="circle-small"></div>
          <div id="circle-medium"></div>
          <div id="circle-large"></div>
          <div id="circle-xlarge"></div>
          <div id="circle-xxlarge"></div>
        </div> */}
        <Container fluid className="p-0 text">
          <Row className="no-gutters" style={{ width: "100%", marginLeft: "0.1px" }}>
            <Col md="8" className="text-center">
              <div className="sign-in-detail text-white">
                <h1
                  style={{
                    color: "#fff",
                    lineHeight: "44px",
                    textAlign: "initial",
                    paddingTop: "70px",
                  }}
                >
                  PA WebPortal Admin Console
                </h1>
                <h4
                  style={{
                    color: "#fff",
                    lineHeight: "44px",
                    textAlign: "initial",
                  }}
                >
                  Dashboard Login
                </h4>
                {/* <Link className="sign-in-logo mb-5" to="#">
                  <Image src={logo} className="img-fluid" alt="logo" />
                </Link> */}
                {/* <div className="sign-slider overflow-hidden text">
                  <Swiper
                    spaceBetween={30}
                    centeredSlides={true}
                    autoplay={{
                      delay: 2000,
                      disableOnInteraction: false,
                    }}
                    className="list-inline m-0 p-0 "
                  >
                    <SwiperSlide>
                      <Image
                        src={login1}
                        className="img-fluid mb-4"
                        alt="logo"
                      />
                      <h4 className="mb-1 text">Find new friends</h4>
                      <p>
                        It is a long established fact that a reader will be
                        distracted by the readable content.
                      </p>
                    </SwiperSlide>
                    <SwiperSlide>
                      <Image
                        src={login2}
                        className="img-fluid mb-4"
                        alt="logo"
                      />
                      <h4 className="mb-1 text">Connect with the world</h4>
                      <p>
                        It is a long established fact that a reader will be
                        distracted by the readable content.
                      </p>
                    </SwiperSlide>
                    <SwiperSlide>
                      <Image
                        src={login3}
                        className="img-fluid mb-4"
                        alt="logo"
                      />
                      <h4 className="mb-1 text">Create new events</h4>
                      <p>
                        It is a long established fact that a reader will be
                        distracted by the readable content.
                      </p>
                    </SwiperSlide>
                  </Swiper>
                </div> */}
              </div>
            </Col>
            <Col md="4" className="bg-white  pb-lg-0 ">
              <div className="sign-in-from mt-5">
                {isValid.call &&
                  (isValid.success ? (
                    <Alert variant="success">{isValid.msg}</Alert>
                  ) : (
                    <Alert variant="danger">{isValid.msg}</Alert>
                  ))}
                <div style={{ textAlign: "center", paddingLeft: "50px" }}>
                  <Image src={logo} className="img-fluid" alt="logo" />
                </div>
                <h3 className="mb-0 text" style={{ fontWeight: "600" }}>Recover password</h3>
                <p>Enter your email address and OTP to set new password.</p>
                <Form className="mt-4" noValidate onSubmit={handleSubmit}>
                  <Form.Group className="form-group">
                    <Form.Label>Email address</Form.Label>
                    <Form.Control
                      type="email"
                      className="mb-0"
                      id="email"
                      name="email"
                      placeholder="Enter email"
                      onChange={handlUserInput}
                      required
                    />
                    <p className="errortext">{formErrors.email}</p>
                  </Form.Group>
                  <Form.Group className="form-group">
                    <Form.Label>OTP</Form.Label>
                    <Form.Control
                      type="number"
                      className="mb-0"
                      id="otp"
                      name="otp"
                      placeholder="OTP"
                      onChange={handlUserInput}
                      required
                    />
                    <p className="errortext">{formErrors.otp}</p>
                  </Form.Group>
                  <Form.Group className="form-group" style={{ position: "relative" }}>
                    <Form.Label>New Password</Form.Label>
                    <Form.Control
                      type={visiblePassword ? "text" : "password"}
                      className="mb-0"
                      id="password"
                      name="new_password"
                      placeholder="Password"
                      onChange={handlUserInput}
                      required
                    />
                    <div
                      style={{ position: "absolute", right: "4%", bottom: "8%", cursor: "pointer" }}
                    >
                      {(visiblePassword === false) ? <i onClick={() => { handleVisible("password") }} class="ri-eye-line"></i> : <i onClick={() => { handleVisible("password") }} class="ri-eye-off-line"></i>}
                    </div>
                  </Form.Group>
                  <p className="errortext">{formErrors.new_password}</p>
                  <Form.Group className="form-group" style={{ position: "relative" }}>
                    <Form.Label>Confirm Password</Form.Label>
                    <Form.Control
                      type={visibleConfirmPassword ? "text" : "password"}
                      className="mb-0"
                      id="confirm-password"
                      name="confirm_password"
                      placeholder="Confirm-Password"
                      onChange={handlUserInput}
                      required
                    />
                    <div
                      style={{ position: "absolute", right: "4%", bottom: "8%", cursor: "pointer" }}
                    >
                      {(visibleConfirmPassword === false) ? <i onClick={() => { handleVisible("confirm_password") }} class="ri-eye-line"></i> : <i onClick={() => { handleVisible("confirm_password") }} class="ri-eye-off-line"></i>}
                    </div>
                  </Form.Group>
                  <p className="errortext">{formErrors.confirm_password}</p>
                  <div className="d-inline-block w-100">
                    <Button type="submit" className="btn-primary float-start">
                      Submit
                    </Button>
                  </div>
                </Form>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default Recoverypw;
