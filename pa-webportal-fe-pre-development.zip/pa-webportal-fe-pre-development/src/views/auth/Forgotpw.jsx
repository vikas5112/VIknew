import React, { useState } from "react";
import {
  Row,
  Col,
  Button,
  Form,
  Container,
  Image,
  Alert,
} from "react-bootstrap";
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";
import "./index.scss";

//swiper
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Navigation, Autoplay } from "swiper";

// Import Swiper styles
import "swiper/swiper-bundle.min.css";
import "swiper/components/navigation/navigation.scss";

// img
import logo from "../../assets/images/main_logo.webp";
import { validation } from "./FormValidation";
import { useRecoveryOtpMutation } from "../../store/user/userApiSlice";

// install Swiper modules
SwiperCore.use([Navigation, Autoplay]);

const Forgotpw = () => {
  const [userInput, setUserInput] = useState({ email: "" });
  const [formErrors, setFormErrors] = useState({});
  const [isValid, setIsValid] = useState({
    call: false,
    success: false,
    msg: "bbbb",
  });
  let history = useHistory();
  const [recoveryOtp] = useRecoveryOtpMutation();

  const handleEmail = (e) => {
    setUserInput({ email: e.target.value });
  };

  const recoverpw = async (event) => {
    event.preventDefault();
    event.stopPropagation();
    setFormErrors(validation(userInput));
    console.log("submit");

    if (Object.keys(validation(userInput)).length === 0) {
      const res = await recoveryOtp(userInput);

      console.log("res", res);
      const data = res?.data;
      if (res?.data?.status === 1) {
        setIsValid({
          ...isValid,
          call: true,
          success: true,
          msg: data?.message,
        });
        history.push("/auth/recoverpw");
        validation("clear error");
      } else {
        if (res?.error?.status === 400) {
          setIsValid({
            ...isValid,
            call: true,
            success: false,
            msg: res?.error?.data.data[0].msg,
          });
        } else {
          res.json().then((data) => {
            setIsValid({
              ...isValid,
              call: true,
              success: false,
              msg: res?.data?.message,
            });
            // console.log(error);;
          });
        }
      }

      validation("clear error");
    }
  };
  console.log(userInput);
  return (
    <>
      <section className="sign-in-page">
        <Container fluid className="p-0">
          <Row className="no-gutters" style={{ width: "100%", marginLeft: "0.1px" }}>
            <Col md="8" className="text-center ">
              <div className="sign-in-detail text-white">
                <h1
                  style={{
                    color: "#fff",
                    lineHeight: "44px",
                    textAlign: "initial",
                    paddingTop: "30px",
                  }}
                >
                  PA WebPortal Admin Console
                </h1>
                <h4
                  style={{
                    color: "#fff",
                    lineHeight: "44px",
                    textAlign: "initial",
                  }}
                >
                  Dashboard Login
                </h4>
              </div>
            </Col>
            <Col md="4" className="bg-white  pb-lg-0 pb-5">
              <div className="sign-in-from text mt-5">
                {isValid.call &&
                  (isValid.success ? (
                    <Alert variant="success">{isValid.msg}</Alert>
                  ) : (
                    <Alert variant="danger">{isValid.msg}</Alert>
                  ))}
                <div style={{ textAlign: "center", paddingLeft: "50px" }}>
                  <Image src={logo} className="img-fluid" alt="logo" />
                </div>
                <h3 className="mb-0 text" style={{ fontWeight: "600" }}>
                  Reset Password
                </h3>
                <p>
                  Enter your email address and we'll send you an OTP to reset
                  your password.
                </p>
                <Form className="mt-4">
                  <Form.Group>
                    <Form.Label>Email Address</Form.Label>
                    <Form.Control
                      type="email"
                      className="mb-0"
                      id="exampleInputEmail1"
                      placeholder="Enter Email"
                      onChange={handleEmail}
                    />
                    <p className="errortext">{formErrors.email}</p>
                  </Form.Group>
                  <div className="d-inline-block w-100">
                    <Button
                      variant="primary"
                      type="button"
                      className="float-right mt-3"
                      onClick={recoverpw}
                    >
                      GET OTP
                    </Button>
                  </div>
                </Form>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default Forgotpw;
