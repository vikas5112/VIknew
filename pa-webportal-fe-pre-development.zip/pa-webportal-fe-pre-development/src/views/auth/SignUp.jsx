import React, { useState } from "react";
import {
  Row,
  Col,
  Container,
  Form,
  Button,
  Image,
  Alert,
} from "react-bootstrap";
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";
import { setUser } from "../../store/user/action";
import { useSelector, useDispatch } from "react-redux";
import "./index.scss";

//swiper
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Navigation, Autoplay } from "swiper";

// Import Swiper styles
import "swiper/swiper-bundle.min.css";
import "swiper/components/navigation/navigation.scss";

//img
import logo from "../../assets/images/main_logo.webp";

import { signupvalidation } from "./FormValidation";
import { useSignupMutation } from "../../store/user/userApiSlice";

// install Swiper modules
SwiperCore.use([Navigation, Autoplay]);

const SignUp = () => {
  const [check, setCheck] = useState(false);
  const [visiblePassword, setVisiblePassword] = useState(false);
  const [visibleConfirmPassword, setVisibleConfirmPassword] = useState(false);
  const [formErrors, setFormErrors] = useState({});
  const [isSubmit, setIsSubmit] = useState(false);
  const [userInput, setUserInput] = useState({
    first_name: "",
    last_name: "",
    email: "",
    password: "",
    confirm_password: "",
    phone: "",
    user_type: "student",
    public_vapid_key: 90,
  });
  const [isValid, setIsValid] = useState({
    call: false,
    success: false,
    msg: "",
  });
  const user = useSelector((state) => state.user);
  let history = useHistory();
  const dispatch = useDispatch();
  const [signup] = useSignupMutation();

  const handlUserInput = (e) => {
    const { value, name } = e.target;
    setUserInput({ ...userInput, [name]: value });
    if (name === "check") {
      setCheck(e.target.checked);
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    event.stopPropagation();
    setIsSubmit(true);
    setFormErrors(signupvalidation(userInput));
    dispatch(setUser("data"));

    if (Object.keys(signupvalidation(userInput)).length === 0) {
      const res = await signup(userInput);
      const data = res?.data;
      if (res?.data?.status === 1) {
        setIsValid({
          ...isValid,
          call: true,
          success: true,
          msg: data?.message,
        });
        dispatch(setUser(data.data));
        history.push("/auth/confirm-mail");
        signupvalidation("clear error");
      } else {
        if (res?.error?.status === 400) {
          setIsValid({
            ...isValid,
            call: true,
            success: false,
            msg: res?.error?.data?.data[0].msg,
          });
        } else {
          res.json().then((data) => {
            setIsValid({
              ...isValid,
              call: true,
              success: false,
              msg: res?.data?.msg,
            });
          });
        }
      }
      signupvalidation("clear error");
    }
  };

  const handleVisible = (value) => {
    if (value === "password") {
      setVisiblePassword(!visiblePassword);
    }
    if (value === "confirm_password") {
      setVisibleConfirmPassword(!visibleConfirmPassword);
    }
  };

  return (
    <>
      <section className="sign-in-page">
        <Container fluid className="p-0 text">
          <Row className="no-gutters" style={{ width: "100%", marginLeft: "0.1px" }}>
            <Col md="8" className="text-center">
              <div className="sign-in-detail text-white mb-5">
                <h1
                  style={{
                    color: "#fff",
                    lineHeight: "44px",
                    textAlign: "initial",
                    paddingTop: "70px",
                  }}
                >
                  PA WebPortal Admin Console
                </h1>
                <h4
                  style={{
                    color: "#fff",
                    lineHeight: "44px",
                    textAlign: "initial",
                  }}
                >
                  Dashboard Login
                </h4>
              </div>
            </Col>
            <Col md="4" className="bg-white  pb-lg-0 ">
              <div className="sign-in-from mt-5">
                {isValid.call &&
                  (isValid.success ? (
                    <Alert variant="success">{isValid.msg}</Alert>
                  ) : (
                    <Alert variant="danger">{isValid.msg}</Alert>
                  ))}
                <div style={{ textAlign: "center", marginLeft: "50px" }}>
                  <Image src={logo} className="img-fluid" alt="logo" />
                </div>
                <Link className="sign-in-logo mb-5" to="#"></Link>
                <h3 className="mb-0 text" style={{ fontWeight: "600" }}>
                  Sign Up
                </h3>
                <p>Enter the details below to complete the Sign Up</p>
                <Form className="mt-4" noValidate onSubmit={handleSubmit}>
                  <Form.Group className="form-group">
                    <Form.Label>User Type</Form.Label>
                    <select
                      className="form-select"
                      name="user_type"
                      id="choices-multiple-default"
                      onChange={handlUserInput}
                      required
                    >
                      <option value="student">Student</option>
                      <option value="trainer">Trainer</option>
                      <option value="family">Family</option>
                      <option value="admin">Admin</option>
                    </select>
                    <p className="errortext">{formErrors.user_type}</p>
                  </Form.Group>
                  <Form.Group className="form-group">
                    <Form.Label>First Name</Form.Label>
                    <Form.Control
                      type="text"
                      className="mb-0"
                      id="first-name"
                      name="first_name"
                      placeholder="First Name"
                      onChange={handlUserInput}
                      required
                    />
                    <p className="errortext">{formErrors.first_name}</p>
                  </Form.Group>
                  <Form.Group className="form-group">
                    <Form.Label>Last Name</Form.Label>
                    <Form.Control
                      type="text"
                      className="mb-0"
                      id="last-name"
                      name="last_name"
                      placeholder="Last Name"
                      onChange={handlUserInput}
                      required
                    />
                    <p className="errortext">{formErrors.last_name}</p>
                  </Form.Group>
                  <Form.Group className="form-group">
                    <Form.Label>Email Address</Form.Label>
                    <Form.Control
                      type="email"
                      className="mb-0"
                      id="email"
                      name="email"
                      placeholder="Enter Email"
                      onChange={handlUserInput}
                      required
                    />
                    <p className="errortext">{formErrors.email}</p>
                  </Form.Group>
                  <Form.Group className="form-group">
                    <Form.Label>Phone</Form.Label>
                    <Form.Control
                      type="number"
                      className="mb-0"
                      id="phone"
                      name="phone"
                      placeholder="Phone"
                      onChange={handlUserInput}
                    />
                  </Form.Group>
                  <Form.Group className="form-group" style={{ position: "relative" }}>
                    <Form.Label>Password</Form.Label>
                    <Form.Control
                      type={visiblePassword ? "text" : "password"}
                      className="mb-0"
                      id="password"
                      name="password"
                      placeholder="Password"
                      onChange={handlUserInput}
                      required
                    />
                    <div
                      style={{ position: "absolute", right: "4%", bottom: "8%", cursor: "pointer" }}
                    >
                      {(visiblePassword === false) ? <i onClick={() => { handleVisible("password") }} class="ri-eye-line"></i> : <i onClick={() => { handleVisible("password") }} class="ri-eye-off-line"></i>}
                    </div>
                  </Form.Group>
                  <p className="errortext">{formErrors.password}</p>
                  <Form.Group className="form-group" style={{ position: "relative" }}>
                    <Form.Label>Confirm Password</Form.Label>
                    <Form.Control
                      type={visibleConfirmPassword ? "text" : "password"}
                      className="mb-0"
                      id="confirm-password"
                      name="confirm_password"
                      placeholder="Confirm-Password"
                      onChange={handlUserInput}
                      required
                    />
                    <div
                      style={{ position: "absolute", right: "4%", bottom: "8%", cursor: "pointer" }}
                    >
                      {(visibleConfirmPassword === false) ? <i onClick={() => { handleVisible("confirm_password") }} class="ri-eye-line"></i> : <i onClick={() => { handleVisible("confirm_password") }} class="ri-eye-off-line"></i>}
                    </div>
                  </Form.Group>
                  <p className="errortext">{formErrors.confirm_password}</p>
                  <div className="d-inline-block w-100">
                    <Form.Check className="d-inline-block mt-2 pt-1">
                      <Form.Check.Input
                        required
                        type="checkbox"
                        className="me-2"
                        id="customCheck1"
                        name="check"
                        onChange={handlUserInput}
                      />
                      <Form.Check.Label>
                        I accept{" "}
                        <Link to="#">
                          <span className="text">Terms and Conditions</span>
                        </Link>
                      </Form.Check.Label>
                    </Form.Check>
                    <p className="errortext">{formErrors.check}</p>
                    <Button
                      type="submit"
                      className="btn-primary float-end"
                      defaultChecked
                      disabled={check ? "" : "disabled"}
                    >
                      Sign Up
                    </Button>
                  </div>
                  <div className="sign-info">
                    <span className="dark-color d-inline-block line-height-2">
                      Already Have Account ?{" "}
                      <Link to="/auth/sign-in">Log In</Link>
                    </span>
                  </div>
                </Form>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default SignUp;