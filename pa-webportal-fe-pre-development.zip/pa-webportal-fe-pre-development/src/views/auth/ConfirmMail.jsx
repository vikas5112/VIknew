import React, { useState } from "react";
import { Row, Col, Container, Image, Button, Form } from "react-bootstrap";
import Alert from "react-bootstrap/Alert";
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";

//swiper
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Navigation, Autoplay } from "swiper";

// Import Swiper styles
import "swiper/swiper-bundle.min.css";
import "swiper/components/navigation/navigation.scss";

//image
import logo from "../../assets/images/main_logo.webp";

import { useSelector } from "react-redux";
import { validation } from "./FormValidation";
import { useConfirmMailMutation } from "../../store/user/userApiSlice";

// install Swiper modules
SwiperCore.use([Navigation, Autoplay]);

const ConfirmMail = () => {
  const [otp, setOtp] = useState("");
  const [formErrors, setFormErrors] = useState({});
  const [isValid, setIsValid] = useState({
    call: false,
    success: false,
    msg: "bbbb",
  });

  const user = useSelector((state) => state.user);
  let history = useHistory();
  const [confirmMail] = useConfirmMailMutation();

  console.log("user redux", user);

  const handleOtp = (e) => {
    setOtp(e.target.value);
  };
  const handleSubmit = async (event) => {
    event.preventDefault();
    setFormErrors(validation({ otp }));

    if (Object.keys(validation({ otp })).length === 0) {
      const res = await confirmMail({
        otp: otp,
        email: user?.userDetails?.email,
      });

      console.log("confirmMail", res);
      const data = res?.data;
      if (res?.data?.status === 1) {
        setIsValid({
          ...isValid,
          call: true,
          success: true,
          msg: data?.message,
        });
        alert("Registeration Completed");
        history.push("/auth/sign-in");
        validation("clear error");
      } else {
        if (res?.error?.status === 500) {
          setIsValid({
            ...isValid,
            call: true,
            success: false,
            msg: res?.error?.data?.message,
          });
        } else {
          res.json().then((data) => {
            setIsValid({
              ...isValid,
              call: true,
              success: false,
              msg: res?.data?.msg,
            });
            // console.log(error);;
          });
        }
      }

      validation("clear error");
    }
  };

  return (
    <>
      <section className="sign-in-page">
        <Container fluid className="p-0">
          <Row className="no-gutters">
            <Col md="8" className="text-center pt-5">
              <div className="sign-in-detail text-white"></div>
            </Col>
            <Col md="4" className="bg-white pt-5 pt-5 pb-lg-0 pb-5">
              <div className="sign-in-from">
                {isValid.call &&
                  (isValid.success ? (
                    <Alert variant="success">{isValid.msg}</Alert>
                  ) : (
                    <Alert variant="danger">{isValid.msg}</Alert>
                  ))}
                {/* <Image src={mail} width="80"  alt=""/> */}
                <div style={{ textAlign: "center", paddingLeft: "50px" }}>
                  <Image src={logo} className="img-fluid" alt="logo" />
                </div>
                <h3 className="mt-3 mb-0" style={{ fontWeight: "600" }}>
                  Verify Mail !
                </h3>
                <p>
                  An otp has been sent to your {user?.userDetails?.email} Please
                  check for an email.
                </p>
                <Form.Group>
                  <Form.Label>Enter OTP</Form.Label>
                  <Form.Control
                    type="email"
                    className="mb-0"
                    id="exampleInputEmail1"
                    placeholder="Enter OTP"
                    onChange={handleOtp}
                  />
                  <p className="errortext">{formErrors.otp}</p>
                </Form.Group>
                <div className="d-inline-block w-100">
                  <Button
                    type="button"
                    onClick={handleSubmit}
                    variant="primary"
                    className="mt-3"
                  >
                    <span className="d-flex align-items-center">
                      <i className="material-symbols-outlined md-18 me-1">
                        home
                      </i>
                      Verify
                    </span>
                  </Button>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default ConfirmMail;
