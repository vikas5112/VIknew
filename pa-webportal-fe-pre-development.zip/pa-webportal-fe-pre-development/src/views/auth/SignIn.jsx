import React, { useEffect, useState } from "react";
import {
  Row,
  Col,
  Container,
  Form,
  Button,
  Image,
  Alert,
} from "react-bootstrap";
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";
import "./index.scss";
import { useSelector, useDispatch } from "react-redux";
import { setUser } from "../../store/user/action";
import { useLoginMutation } from "../../store/user/userApiSlice";
//swiper

import SwiperCore, { Navigation, Autoplay } from "swiper";

// Import Swiper styles
import "swiper/swiper-bundle.min.css";
import "swiper/components/navigation/navigation.scss";

//img
import logo from "../../assets/images/main_logo.webp";

import { validation } from "./FormValidation";

SwiperCore.use([Navigation, Autoplay]);

const SignIn = () => {
  const [formErrors, setFormErrors] = useState({});
  const [isSubmit, setIsSubmit] = useState(false);
  const [visiblePassword, setVisiblePassword] = useState(false);
  const [userInput, setUserInput] = useState({
    email: "",
    password: "",
  });
  const [isValid, setIsValid] = useState({
    call: false,
    success: false,
    msg: "bbbb",
  });
  const user = useSelector((state) => state.user);

  let history = useHistory();
  const [login] = useLoginMutation();
  const handleUserInput = (e) => {
    const { value, name } = e.target;
    setUserInput({ ...userInput, [name]: value });
  };

  let dispatch = useDispatch();
  const handleSubmit = async (event) => {
    event.preventDefault();
    event.stopPropagation();
    setIsSubmit(true);
    setFormErrors(validation(userInput));

    if (Object.keys(validation(userInput)).length === 0) {
      const res = await login(userInput);
      const data = res?.data;
      if (res?.data?.status === 1) {
        setIsValid({
          ...isValid,
          call: true,
          success: true,
          msg: data?.message,
        });
        localStorage.setItem("token", data?.data?.token);
        dispatch(setUser(data?.data));
        localStorage.setItem("userDetail", JSON.stringify(data?.data));
        history.push("/");
        validation("clear error");
      } else {
        if (res?.error?.status === 500) {
          setIsValid({
            ...isValid,
            call: true,
            success: false,
            msg: res?.error?.data?.message,
          });
          console.log(res?.error?.data?.message);
        } else {
          res.json().then((data) => {
            setIsValid({
              ...isValid,
              call: true,
              success: false,
              msg: res?.error?.data?.message
                ? res?.error?.data?.message
                : "user is blocked by admin",
            });
          });
        }
      }
      validation("clear error");
    }
  };

  useEffect(() => {
    if (Object.keys(formErrors).length === 0 && isSubmit) {
    }
  }, [formErrors]);

  const handleVisible = (value) => {
    setVisiblePassword(!visiblePassword);
  };

  return (
    <>
      <section className="sign-in-page">
        <div >
          <Row className="no-gutters" style={{ width: "100%", marginLeft: "0.1px" }}>
            <Col md="8" className="text-center " >
              <div className="sign-in-detail text-white">
                <h1
                  style={{
                    color: "#fff",
                    lineHeight: "44px",
                    textAlign: "initial",
                    paddingTop: "30px",
                  }}
                >
                  PA WebPortal Admin Console
                </h1>
                <h4
                  style={{
                    color: "#fff",
                    lineHeight: "44px",
                    textAlign: "initial",
                  }}
                >
                  Dashboard Login
                </h4>
              </div>
            </Col>
            <Col md="4" className="bg-white  pb-lg-0 ">
              <div className="sign-in-from mt-5">
                {isValid.call &&
                  (isValid.success ? (
                    <Alert variant="success">{isValid.msg}</Alert>
                  ) : (
                    <Alert variant="danger">{isValid.msg}</Alert>
                  ))}
                <div style={{ textAlign: "center", paddingLeft: "50px" }}>
                  <Image src={logo} className="img-fluid" alt="logo" />
                </div>
                <h3 className="mb-0 text" style={{ fontWeight: "600" }}>
                  Sign In
                </h3>
                <p>
                  Enter your email address and password to access admin panel.
                </p>
                <Form className="mt-4" noValidate onSubmit={handleSubmit}>
                  <Form.Group className="form-group">
                    <Form.Label>Email Address</Form.Label>
                    <Form.Control
                      required
                      type="email"
                      className="mb-0"
                      id="exampleInputEmail1"
                      placeholder="Enter Email"
                      name="email"
                      onChange={handleUserInput}
                    />
                    <p className="errortext">{formErrors.email}</p>
                  </Form.Group>
                  <Form.Group className="form-group" style={{ position: "relative" }}>
                    <Form.Label>Password</Form.Label>
                    <Link to="/auth/forgotpw" className="float-end">
                      Forgot Password?
                    </Link>
                    <Form.Control
                      required
                      type={visiblePassword ? "text" : "password"}
                      className="mb-0"
                      id="exampleInputPassword1"
                      placeholder="Password"
                      name="password"
                      onChange={handleUserInput}
                    />
                    <div
                      style={{ position: "absolute", right: "4%", bottom: "7%", cursor: "pointer" }}
                    >
                      {(visiblePassword === false) ? <i onClick={() => { handleVisible("current_password") }} class="ri-eye-line"></i> : <i onClick={() => { handleVisible("current_password") }} class="ri-eye-off-line"></i>}
                    </div>
                  </Form.Group>
                  <p className="errortext">{formErrors.password}</p>
                  <div className="d-inline-block w-100">
                    <Form.Check className="d-inline-block mt-2 pt-1">
                      <Form.Check.Input
                        type="checkbox"
                        className="me-2"
                        id="customCheck11"
                      />
                      <Form.Check.Label>Remember Me</Form.Check.Label>{" "}
                    </Form.Check>
                    <Button
                      variant="primary"
                      type="submit"
                      className="float-end"
                    >
                      Sign In
                    </Button>
                  </div>
                  <div className="sign-info">
                    <span className="dark-color d-inline-block line-height-2">
                      Don't have an account?{" "}
                      <Link to="/auth/sign-up">Sign Up</Link>
                    </span>
                  </div>
                </Form>
              </div>
            </Col>
          </Row>
        </div>
      </section>
    </>
  );
};

export default SignIn;