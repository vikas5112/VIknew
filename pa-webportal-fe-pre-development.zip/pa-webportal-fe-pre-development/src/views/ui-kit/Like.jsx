import React, { useState } from "react";

const RenderLike = ({ handleLike, data }) => {
  const [isLike, setIsLike] = useState(data?.is_liked ? data?.is_liked :false);
  const [likeCount, setLikeCount] = useState(data?.like_count);
  return (
    <div className="total-like-block ms-2 me-3">
      <span
        onClick={() => {
          handleLike(data._id);
          if(isLike){
            setLikeCount(likeCount-1)
            setIsLike(false);

          }else{
            setLikeCount(likeCount+1)
            setIsLike(true);
          }
        }}
      >
        <i className={isLike ? "fas fa-thumbs-down" : "fas fa-thumbs-up"}></i>
      </span>{" "}
      {`${likeCount} Likes`}
    </div>
  );
};

export default RenderLike;
