import React, { useState, useEffect } from "react";
import { useGetInvitationsQuery } from "../../store/connection/connectionApiSlice";
import {useDispatch} from 'react-redux';
import {setInvitation} from '../../store/connection/action'
import {
  Row,
  Col,
  Container,
  Dropdown,
  OverlayTrigger,
  Tooltip,
  Modal,
} from "react-bootstrap";
import { Link } from "react-router-dom";
import Card from "../../components/Card";
import TextEditor from "../../components/TextEditor";
import CustomToggle from "../../components/Dropdowns";
import ShareOffcanvas from "../../components/ShareOffcanvas";
import {
  useCreatePostMutation,
  useGetPostsQuery,
  useFeedUploadMutation,
  useLikePostMutation,
} from "../../store/post/postApiSlice";
import { useGetAllUsersQuery } from "../../store/user/userApiSlice";
import { useCreateConnectionMutation } from "../../store/connection/connectionApiSlice";
import RenderFile from "../../components/RenderFile";
import FeedBlock from "../../components/FeedBlock";

import s2 from "../../assets/images/page-img/s2.jpg";

import loader from "../../assets/images/page-img/page-load-loader.gif";

const Index = () => {
  const [show, setShow] = useState(false);
  const [text, setText] = useState("");
  const [file, setFile] = useState(null);
  const [allDisplayedUsers, setAllDisplayedUsers] = useState([]);
  const [allPosts, setAllPosts] = useState([]);
  const [textEditorData, setTextEditorData] = useState(null);
  const handleClose = () => {
    setTextEditorData(null);
    setShow(false);
  };
  const handleShow = () => setShow(true);
  const localStorageUser = localStorage.getItem("userDetail");
  const user = localStorageUser ? JSON.parse(localStorageUser) : {};
  const [createPost] = useCreatePostMutation();
  const [createConnection] = useCreateConnectionMutation();
  const [feedUpload] = useFeedUploadMutation();
  const [likePost] = useLikePostMutation();
  const getPost = useGetPostsQuery();
  const allUsers = useGetAllUsersQuery();
  const {data} = useGetInvitationsQuery();
  console.log("hii", {data})
  const dispatch = useDispatch();

  useEffect(() => {
    if (allUsers?.data?.status === 1) {
      setAllDisplayedUsers(allUsers?.data?.data);
    }
  }, [allUsers?.data]);

  useEffect(() => {
    
    if (data && data?.status === 1 && data?.data?.length > 0) {
      dispatch(setInvitation(data?.data))  
    }
  }, [data]);

  console.log(textEditorData, "tete");
  useEffect(() => {
    if (getPost?.data?.status === 1) {
      setAllPosts(getPost?.data?.data);
    }
  }, [getPost?.data]);
  const handleTextChange = (event) => {
    setText(event.target.value);
  };

  const uploadMediaHandle = (fileData) => {
    setFile(fileData);
  };

  const handleSentInvite = async (id) => {
    const res = await createConnection({
      user_id: id,
    });
    if (res?.data?.status === 1) {
      let newList = allDisplayedUsers.filter((val) => val._id != id);
      setAllDisplayedUsers(newList);
    }
  };

  const handleLike = async (id) => {
    const result = await likePost({
      post_id: id,
    });
    console.log(result?.data?.status, "ress", result?.data?.data);
  };

  const handleSubmit = async () => {
    let multerData = new FormData();

    multerData.append("file", file);

    let payload;
    if (file) {
      const feedRes = await feedUpload(multerData);
      payload = {
        // plain_text: text,
        text_editor_data: textEditorData,
        files: {
          ref: feedRes?.data?.data?.data?._id,
          url: feedRes?.data?.data?.data?.file_url,
        },
      };
      if (feedRes?.data?.status === 1) {
      } else {
        console.log("ERROR in POST upload");
        return;
      }
    } else {
      payload = {
        // plain_text: text,
        text_editor_data: textEditorData,
      };
    }
    const result = await createPost(payload);
    if (result?.data?.status === 1) {
      getPost.refetch();
      setFile(null);
      handleClose();
    }
  };

  return (
    <>
      <Container>
        <Row>
          {/* <Col lg={8} className="row m-0 p-0"> */}
          <Col lg={8} className="m-0 p-0">
            <Col sm={12}>
              <Card
                id="post-modal-data"
                className="card-block card-stretch card-height"
              >
                <div className="card-header d-flex justify-content-between">
                  <div className="header-title">
                    <h4 className="card-title">Create Post</h4>
                  </div>
                </div>
                <Card.Body>
                  <div className="d-flex align-items-center">
                    <div className="user-img">
                      <img
                        src={
                          user?.profile_picture
                            ? user?.profile_picture
                            : "https://jbpbucket-dev.s3.amazonaws.com/devjanbask/profile_pic/f65d1d56-5887-4abb-b4f1-a3100975g718.jpg"
                        }
                        alt="user1"
                        className="avatar-60 rounded-circle"
                      />
                    </div>
                    <form
                      className="post-text ms-3 w-100 "
                      onClick={handleShow}
                    >
                      <input
                        type="text"
                        className="form-control rounded"
                        placeholder="Write something here..."
                        style={{ border: "none" }}
                      />
                    </form>
                  </div>
                  <hr />
                </Card.Body>
                <Modal
                  size="lg"
                  className=" fade"
                  id="post-modal"
                  onHide={handleClose}
                  show={show}
                >
                  <Modal.Header className="d-flex justify-content-between">
                    <Modal.Title id="post-modalLabel">Create Post</Modal.Title>
                    <Link to="#" className="lh-1" onClick={handleClose}>
                      <span className="material-symbols-outlined">close</span>
                    </Link>
                  </Modal.Header>
                  <Modal.Body>
                    <div className="d-flex align-items-center">
                      <div className="user-img">
                        <img
                          src={
                            user?.profile_picture
                              ? user?.profile_picture
                              : "https://jbpbucket-dev.s3.amazonaws.com/devjanbask/profile_pic/f65d1d56-5887-4abb-b4f1-a3100975g718.jpg"
                          }
                          alt="user1"
                          className="avatar-60 rounded-circle img-fluid"
                        />
                      </div>
                      <form
                        className="post-text ms-3 w-100 "
                        data-bs-toggle="modal"
                        data-bs-target="#post-modal"
                      >
                        <TextEditor
                          textEditorData={textEditorData}
                          onChange={setTextEditorData}

                          // urlDetails={urlDetails}
                          // fetchUrlDetails={fetchUrlDetails}
                        />
                        {/* <input
                          type="text"
                          className="form-control rounded"
                          onChange={handleTextChange}
                          placeholder="Write something here..."
                          style={{ border: "none" }}
                        /> */}
                      </form>
                    </div>
                    <hr />
                    <ul className="d-flex flex-wrap align-items-center list-inline m-0 p-0">
                      <li className="col-md-6 mb-3">
                        <div className="bg-soft-primary rounded p-2 pointer me-3">
                          <label className="shareOption">
                            <span>Photo/Video</span>

                            <input
                              style={{ display: "none" }}
                              type="file"
                              id="file"
                              //  accept=".png,.jpeg,.jpg"
                              onChange={(e) => {
                                uploadMediaHandle(e.target.files[0]);
                              }}
                            />
                          </label>
                        </div>
                      </li>
                      <RenderFile file={file} filetype={"filetype"} />
                    </ul>
                    <hr />

                    <button
                      type="submit"
                      className="btn btn-primary d-block w-100 mt-3"
                      onClick={handleSubmit}
                    >
                      Post
                    </button>
                  </Modal.Body>
                </Modal>
              </Card>
            </Col>
            {allPosts?.map((val) => (
              <FeedBlock postDetails={val} handleLike={handleLike} />
            ))}
          
          </Col>
          <Col lg={4}>
            <Card>
              <div className="card-header d-flex justify-content-between">
                <div className="header-title">
                  <h4 className="card-title">People You ma</h4>
                </div>
              </div>
              <Card.Body>
                <ul className="media-story list-inline m-0 p-0">
                  {/* <li className="d-flex mb-3 align-items-center">
                    <i className="ri-add-line"></i>
                    <div className="stories-data ms-3">
                      <h5>Creat Your Story</h5>
                      <p className="mb-0">time to story</p>
                    </div>
                  </li> */}
                  {allDisplayedUsers.map((val, index) => {
                    if (index < allDisplayedUsers.length - 15) {
                      return;
                    }
                    return (
                      <li className="d-flex mb-3 align-items-center active">
                        <img
                          src={val.profile_picture ? val.profile_picture : s2}
                          alt="story-img"
                          className="rounded-circle img-fluid"
                        />
                        <div className="stories-data ms-3">
                          <h5>{`${val.first_name}${" "}${val.last_name}`}</h5>
                          <button
                            type="submit"
                            className="btn btn-primary d-block w-100 mt-1 sendInvite"
                            onClick={() => handleSentInvite(val._id)}
                          >
                            Send Invitation
                          </button>
                        </div>
                      </li>
                    );
                  })}
                  {/* <li className="d-flex mb-3 align-items-center active">
                    <img
                      src={s2}
                      alt="story-img"
                      className="rounded-circle img-fluid"
                    />
                    <div className="stories-data ms-3">
                      <h5>Anna Mull</h5>
                      <p className="mb-0">1 hour ago</p>
                    </div>
                  </li>
                  <li className="d-flex mb-3 align-items-center">
                    <img
                      src={s3}
                      alt="story-img"
                      className="rounded-circle img-fluid"
                    />
                    <div className="stories-data ms-3">
                      <h5>Ira Membrit</h5>
                      <p className="mb-0">4 hour ago</p>
                    </div>
                  </li>
                  <li className="d-flex align-items-center">
                    <img
                      src={s1}
                      alt="story-img"
                      className="rounded-circle img-fluid"
                    />
                    <div className="stories-data ms-3">
                      <h5>Bob Frapples</h5>
                      <p className="mb-0">9 hour ago</p>
                    </div>
                  </li> */}
                </ul>
                <Link to="#" className="btn btn-primary d-block mt-3">
                  See All
                </Link>
              </Card.Body>
            </Card>
            {/* <Card>
              <div className="card-header d-flex justify-content-between">
                <div className="header-title">
                  <h4 className="card-title">Events</h4>
                </div>
                <div className="card-header-toolbar d-flex align-items-center">
                  <Dropdown>
                    <Dropdown.Toggle
                      as={CustomToggle}
                      id="dropdownMenuButton"
                      data-bs-toggle="dropdown"
                      aria-expanded="false"
                      role="button"
                    >
                      <i className="ri-more-fill h4"></i>
                    </Dropdown.Toggle>
                    <Dropdown.Menu
                      className=" dropdown-menu-right"
                      aria-labelledby="dropdownMenuButton"
                    >
                      <Dropdown.Item href="#">
                        <i className="ri-eye-fill me-2"></i>View
                      </Dropdown.Item>
                      <Dropdown.Item href="#">
                        <i className="ri-delete-bin-6-fill me-2"></i>Delete
                      </Dropdown.Item>
                      <Dropdown.Item href="#">
                        <i className="ri-pencil-fill me-2"></i>Edit
                      </Dropdown.Item>
                      <Dropdown.Item href="#">
                        <i className="ri-printer-fill me-2"></i>Print
                      </Dropdown.Item>
                      <Dropdown.Item href="#">
                        <i className="ri-file-download-fill me-2"></i>Download
                      </Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                </div>
              </div>
              <Card.Body>
                <ul className="media-story list-inline m-0 p-0">
                  <li className="d-flex mb-4 align-items-center ">
                    <img
                      src={s4}
                      alt="story1"
                      className="rounded-circle img-fluid"
                    />
                    <div className="stories-data ms-3">
                      <h5>Web Workshop</h5>
                      <p className="mb-0">1 hour ago</p>
                    </div>
                  </li>
                  <li className="d-flex align-items-center">
                    <img
                      src={s5}
                      alt="story2"
                      className="rounded-circle img-fluid"
                    />
                    <div className="stories-data ms-3">
                      <h5>Fun Events and Festivals</h5>
                      <p className="mb-0">1 hour ago</p>
                    </div>
                  </li>
                </ul>
              </Card.Body>
            </Card>
            <Card>
              <div className="card-header d-flex justify-content-between">
                <div className="header-title">
                  <h4 className="card-title">Upcoming Birthday</h4>
                </div>
              </div>
              <Card.Body>
                <ul className="media-story list-inline m-0 p-0">
                  <li className="d-flex mb-4 align-items-center">
                    <img
                      src={user01}
                      alt="story3"
                      className="rounded-circle img-fluid"
                    />
                    <div className="stories-data ms-3">
                      <h5>Anna Sthesia</h5>
                      <p className="mb-0">Today</p>
                    </div>
                  </li>
                  <li className="d-flex align-items-center">
                    <img
                      src={user2}
                      alt="story-img"
                      className="rounded-circle img-fluid"
                    />
                    <div className="stories-data ms-3">
                      <h5>Paul Molive</h5>
                      <p className="mb-0">Tomorrow</p>
                    </div>
                  </li>
                </ul>
              </Card.Body>
            </Card>
            <Card>
              <div className="card-header d-flex justify-content-between">
                <div className="header-title">
                  <h4 className="card-title">Suggested Pages</h4>
                </div>
                <div className="card-header-toolbar d-flex align-items-center">
                  <Dropdown>
                    <Dropdown.Toggle as={CustomToggle}>
                      <i className="ri-more-fill h4"></i>
                    </Dropdown.Toggle>
                    <Dropdown.Menu
                      className="dropdown-menu-right"
                      aria-labelledby="dropdownMenuButton01"
                    >
                      <Dropdown.Item href="#">
                        <i className="ri-eye-fill me-2"></i>View
                      </Dropdown.Item>
                      <Dropdown.Item href="#">
                        <i className="ri-delete-bin-6-fill me-2"></i>Delete
                      </Dropdown.Item>
                      <Dropdown.Item href="#">
                        <i className="ri-pencil-fill me-2"></i>Edit
                      </Dropdown.Item>
                      <Dropdown.Item href="#">
                        <i className="ri-printer-fill me-2"></i>Print
                      </Dropdown.Item>
                      <Dropdown.Item href="#">
                        <i className="ri-file-download-fill me-2"></i>Download
                      </Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                </div>
              </div>
              <Card.Body>
                <ul className="suggested-page-story m-0 p-0 list-inline">
                  <li className="mb-3">
                    <div className="d-flex align-items-center mb-3">
                      <img
                        src={img42}
                        alt="story-img"
                        className="rounded-circle img-fluid avatar-50"
                      />
                      <div className="stories-data ms-3">
                        <h5>Iqonic Studio</h5>
                        <p className="mb-0">Lorem Ipsum</p>
                      </div>
                    </div>
                    <img
                      src={img9}
                      className="img-fluid rounded"
                      alt="Responsive"
                    />
                    <div className="mt-3">
                      <Link to="#" className="btn d-block">
                        <i className="ri-thumb-up-line me-2"></i> Like Page
                      </Link>
                    </div>
                  </li>
                  <li>
                    <div className="d-flex align-items-center mb-3">
                      <img
                        src={img42}
                        alt="story-img"
                        className="rounded-circle img-fluid avatar-50"
                      />
                      <div className="stories-data ms-3">
                        <h5>Cakes & Bakes </h5>
                        <p className="mb-0">Lorem Ipsum</p>
                      </div>
                    </div>
                    <img
                      src={img10}
                      className="img-fluid rounded"
                      alt="Responsive"
                    />
                    <div className="mt-3">
                      <Link to="#" className="btn d-block">
                        <i className="ri-thumb-up-line me-2"></i> Like Page
                      </Link>
                    </div>
                  </li>
                </ul>
              </Card.Body>
            </Card> */}
          </Col>
          <div className="col-sm-12 text-center">
            <img src={loader} alt="loader" style={{ height: "100px" }} />
          </div>
        </Row>
      </Container>
    </>
  );
};

export default Index;
