import React, { useState, useEffect } from "react";
import { useGetInvitaionCountQuery } from "../../../store/user/userApiSlice";
import {
  useGetInvitationsQuery,
  useUpdateStatusMutation,
} from "../../../store/connection/connectionApiSlice";
import { setUser } from "../../../store/user/action";

import { useDispatch, useSelector } from "react-redux";
import {
  Navbar,
  Dropdown,
  Nav,
  Form,
  Card,
  Container,
  Image,
  Offcanvas,
  CloseButton,
} from "react-bootstrap";
import { Link, useHistory } from "react-router-dom";

//image
import logo from "../../../assets/images/main_logo.webp";
import user1 from "../../../assets/images/user/1.jpg";
import user2 from "../../../assets/images/user/02.jpg";
import user3 from "../../../assets/images/user/03.jpg";
import user4 from "../../../assets/images/user/04.jpg";
import user5 from "../../../assets/images/user/05.jpg";
//Componets
import CustomToggle from "../../Dropdowns";
import { logoutUser } from "../../../store/user/action";
const Header = () => {
  const [showDropdown, setShowDropdown] = useState(false);
  const [isHovering, setIsHovering] = useState(false);
  const [countInvite, setCountInvite] = useState({});
  const [displayInvitations, setDisplayInvitations] = useState([]);
  const minisidebar = () => {
    document.getElementsByTagName("ASIDE")[0].classList.toggle("sidebar-mini");
  };

  const { data } = useGetInvitaionCountQuery();
  const invitationData = useGetInvitationsQuery();
  const [updateStatus] = useUpdateStatusMutation();

  useEffect(() => {
    if (
      invitationData?.data &&
      invitationData?.data?.status === 1 &&
      invitationData?.data?.data?.data?.length > 0
    ) {
      setDisplayInvitations(invitationData?.data?.data?.data);
    }
  }, [invitationData?.data]);

  useEffect(() => {
    if (data && data.status === 1) {
      setCountInvite(data.data);
    }
  }, [data]);

  const [show1, setShow1] = useState(false);

  const localStorageUser = localStorage.getItem("userDetail");
  // const user =localStorageUser ? JSON.parse(localStorageUser) :{};
  const userInfo = useSelector((state) => state.user.userDetails);

  const history = useHistory();
  const dispatch = useDispatch();
  useEffect(() => {
    document.getElementsByTagName("ASIDE")[0].classList.toggle("sidebar-mini");
  }, []);

  const handleConfirm = async (id) => {
    const res = await updateStatus({
      id: id,
      status: "active",
    });
    if (res?.data?.status === 1) {
      let newList = displayInvitations.filter((val) => val._id != id);
      setDisplayInvitations(newList);
    }
    userInfo.connection_count = userInfo.connection_count + 1;
    userInfo.invitation_count = userInfo.invitation_count - 1;
    dispatch(setUser(userInfo));
  };

  const handleReject = async (id) => {
    const res = await updateStatus({
      id: id,
      status: "decline",
    });
    if (res?.data?.status === 1) {
      let newList = displayInvitations.filter((val) => val._id != id);
      setDisplayInvitations(newList);
      userInfo.invitation_count = userInfo.invitation_count - 1;
      dispatch(setUser(userInfo));
    }
  };
  const handleMouseEnter = () => {
    setIsHovering(true);
  };

  const handleMouseLeave = () => {
    setIsHovering(false);
  };

  const setDropdown = () => {
    setShowDropdown(!showDropdown)
  }

  return (
    <>
      <div className="iq-top-navbar">
        <Navbar expand="lg" variant="light" className="nav iq-navbar p-lg-0">
          <Container fluid className="navbar-inner">
            <div className="d-flex align-items-center gap-3">
              <Link
                to="/"
                className="d-flex align-items-center gap-2 iq-header-logo d-none d-md-flex"
              >
                <Image className="" src={logo} alt="" loading="lazy" />
              </Link>
              <Link
                to="#"
                className="sidebar-toggle"
                data-toggle="sidebar"
                data-active="true"
                onClick={minisidebar}
              >
                <div className="icon material-symbols-outlined iq-burger-menu">
                  menu
                </div>
              </Link>
            </div>
            <div className="d-block d-md-none">
              <Link
                to="/"
                className="d-flex align-items-center gap-2 iq-header-logo"
              >
                <Image className="" src={logo} alt="" loading="lazy" />
              </Link>
            </div>
            <div className="iq-search-bar device-search">
              <Form action="#" className="searchbox">
                <Link className="search-link" to="#">
                  <span className="material-symbols-outlined">search</span>
                </Link>
                <Form.Control
                  type="text"
                  className="text search-input bg-soft-primary"
                  placeholder="Search here..."
                />
              </Form>
            </div>
            <Link
              className="d-lg-none d-flex"
              to="#"
              aria-expanded={show1}
              data-bs-toggle="collapse"
              data-bs-target="#navbarSupportedContent"
              onClick={() => setShow1(!show1)}
            >
              <span className="material-symbols-outlined">tune</span>
            </Link>
            <div
              className={`offcanvas offcanvas-end iq-profile-menu-responsive ${show1 === true ? "show" : ""
                } `}
              tabIndex="-1"
              id="offcanvasBottom"
              style={{ visibility: `${show1 === true ? "visible" : "hidden"}` }}
            >
              <Offcanvas.Header>
                <h5 id="offcanvasRightLabel">General Setting</h5>
                <CloseButton onClick={() => setShow1(false)} />
                {/* <Button type="button" className="btn-close text-reset"></Button> */}
              </Offcanvas.Header>
              <Offcanvas.Body className="pt-0">
                <ul className="navbar-nav  ms-auto navbar-list">
                  <Nav.Item as="li">
                    <Link to="/" className="d-flex align-items-center">
                      <i className="material-symbols-outlined">home</i>
                      <span className="mobile-text d-lg-none ms-3">Home</span>
                    </Link>
                  </Nav.Item>
                  <Dropdown as="li" className="nav-item d-none d-lg-block">
                    <Dropdown.Toggle
                      href="/"
                      as={CustomToggle}
                      variant="d-flex align-items-center"
                    >
                      <span className="material-symbols-outlined">group</span>
                    </Dropdown.Toggle>
                    <Dropdown.Menu className="sub-drop sub-drop-large">
                      <Card className="shadow-none m-0">
                        <Card.Header className="d-flex justify-content-between bg-primary">
                          <div className="header-title">
                            <h5 className="mb-0 text-white">Friend Request</h5>
                          </div>
                        </Card.Header>
                        <Card.Body className="p-0">
                          {displayInvitations?.map((value) => {
                            return (
                              <div className="iq-friend-request">
                                <div className="iq-sub-card iq-sub-card-big d-flex align-items-center justify-content-between">
                                  <div className="d-flex align-items-center">
                                    <Image
                                      className="avatar-40 rounded"
                                      src={value?.requester?.profile_picture}
                                      alt=""
                                      loading="lazy"
                                    />
                                    <div className="ms-3">
                                      <h6 className="mb-0 ">
                                        {value?.requester?.username}{" "}
                                      </h6>
                                      {/* <p className="mb-0">40 friends</p> */}
                                    </div>
                                  </div>
                                  <div className="d-flex align-items-center">
                                    <div
                                      onClick={() => handleConfirm(value._id)}
                                      className="me-3 btn btn-primary rounded"
                                    >
                                      Confirm
                                    </div>
                                    <div
                                      onClick={() => handleReject(value._id)}
                                      className="me-3 btn btn-secondary rounded"
                                    >
                                      Reject
                                    </div>
                                  </div>
                                </div>
                              </div>
                            );
                          })}

                          <div className="text-center">
                            <Link to="dashboards/app/invitation-list" className=" btn text-primary">
                              View More Request
                            </Link>
                          </div>
                        </Card.Body>
                      </Card>
                    </Dropdown.Menu>
                  </Dropdown>
                  <Nav.Item as="li" className="d-lg-none">
                    <Link
                      to="/dashboard/app/friend-request"
                      className="d-flex align-items-center"
                    >
                      <span className="material-symbols-outlined">group</span>
                      <span className="mobile-text  ms-3">Friend Request</span>
                    </Link>
                  </Nav.Item>
                  <Dropdown as="li" className="nav-item d-none d-lg-block">
                    <Dropdown.Toggle
                      href="#"
                      as={CustomToggle}
                      variant="search-toggle d-flex align-items-center"
                    >
                      <i className="material-symbols-outlined" onClick={() => setShowDropdown(true)}>notifications</i>
                    </Dropdown.Toggle>
                    {showDropdown ? <Dropdown.Menu className="sub-drop">
                      <Card className="shadow-none m-0">
                        <Card.Header className="d-flex justify-content-between bg-primary">
                          <div className="header-title bg-primary">
                            <h5 className="mb-0 text-white">
                              All Notifications
                            </h5>
                          </div>
                          <small className="badge  bg-light text-dark">
                            {countInvite?.notifications_count}
                          </small>
                        </Card.Header>
                        <Card.Body className="p-0">
                          <Link to="#" className="iq-sub-card">
                            <div className="d-flex align-items-center">
                              <div className="">
                                <Image
                                  className="avatar-40 rounded"
                                  src="https://templates.iqonic.design/socialv/bs5/react/build/static/media/1.cfd7137013b37c3af400.jpg"
                                  alt=""
                                  loading="lazy"
                                />
                              </div>
                              <div className="ms-3 w-100">
                                <h6 className="mb-0 ">Emma Watson Bni</h6>
                                <div className="d-flex justify-content-between align-items-center">
                                  <p className="mb-0">95 MB</p>
                                  <small className="float-right font-size-12">
                                    Just Now
                                  </small>
                                </div>
                              </div>
                            </div>
                          </Link>
                          <Link to="#" className="iq-sub-card">
                            <div className="d-flex align-items-center">
                              <div className="">
                                <Image
                                  className="avatar-40 rounded"
                                  src="https://templates.iqonic.design/socialv/bs5/react/build/static/media/02.996984acbcab88366af7.jpg"
                                  alt=""
                                  loading="lazy"
                                />
                              </div>
                              <div className="ms-3 w-100">
                                <h6 className="mb-0 ">New customer is join</h6>
                                <div className="d-flex justify-content-between align-items-center">
                                  <p className="mb-0">Cyst Bni</p>
                                  <small className="float-right font-size-12">
                                    5 days ago
                                  </small>
                                </div>
                              </div>
                            </div>
                          </Link>
                          <Link to="#" className="iq-sub-card">
                            <div className="d-flex align-items-center">
                              <div className="">
                                <Image
                                  className="avatar-40 rounded"
                                  src="https://templates.iqonic.design/socialv/bs5/react/build/static/media/03.e97dd64193aab62ae2af.jpg"
                                  alt=""
                                  loading="lazy"
                                />
                              </div>
                              <div className="ms-3 w-100">
                                <h6 className="mb-0 ">Two customer is left</h6>
                                <div className="d-flex justify-content-between align-items-center">
                                  <p className="mb-0">Cyst Bni</p>
                                  <small className="float-right font-size-12">
                                    2 days ago
                                  </small>
                                </div>
                              </div>
                            </div>
                          </Link>
                          <Link to="#" className="iq-sub-card">
                            <div className="d-flex align-items-center">
                              <div className="">
                                <Image
                                  className="avatar-40 rounded"
                                  src="https://templates.iqonic.design/socialv/bs5/react/build/static/media/05.803eaf62b7ba16bcfa3b.jpg"
                                  alt=""
                                  loading="lazy"
                                />
                              </div>
                              <div className="w-100 ms-3">
                                <h6 className="mb-0 ">New Mail from Fenny</h6>
                                <div className="d-flex justify-content-between align-items-center">
                                  <p className="mb-0">Cyst Bni</p>
                                  <small className="float-right font-size-12">
                                    3 days ago
                                  </small>
                                </div>
                              </div>
                            </div>
                          </Link>
                        </Card.Body>
                        <Card.Header className="d-flex justify-content-between bg-primary notification">
                          <Link to="/dashboard/app/notification" className="view-all-btn" onClick={setDropdown}><button className=" btn header-title notfication-btn" style={{ color: isHovering ? 'white' : '' }} onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
                            View All
                          </button>
                          </Link>
                          <small className="badge  bg-light text-dark">
                            {countInvite?.notifications_count}
                          </small>
                        </Card.Header>
                      </Card>
                    </Dropdown.Menu> : null}
                  </Dropdown>
                  <Nav.Item as="li" className="d-lg-none">
                    <Link
                      to="/dashboard/app/notification"
                      className="d-flex align-items-center"
                    >
                      <i className="material-symbols-outlined">notifications</i>
                      <span className="mobile-text  ms-3">Notifications</span>
                    </Link>
                  </Nav.Item>
                  <Dropdown as="li" className="nav-item d-none d-lg-block">
                    <Dropdown.Toggle
                      href="#"
                      as={CustomToggle}
                      variant="d-flex align-items-center"
                    >
                      <i className="material-symbols-outlined">
                        <Link to="/dashboard/app/chat">mail</Link>
                      </i>
                      <span className="mobile-text d-lg-none ms-3">
                        Message
                      </span>
                    </Dropdown.Toggle>
                    {/* <Dropdown.Menu className="sub-drop">
                      <Card className="shadow-none m-0">
                        <Card.Header className="d-flex justify-content-between bg-primary">
                          <div className="header-title bg-primary">
                            <h5 className="mb-0 text-white">All Message</h5>
                          </div>
                          <small className="badge bg-light text-dark">4</small>
                        </Card.Header>
                        <Card.Body className="p-0 ">
                          <Link to="#" className="iq-sub-card">
                            <div className="d-flex  align-items-center">
                              <div className="">
                                <Image
                                  className="avatar-40 rounded"
                                  src="https://templates.iqonic.design/socialv/bs5/react/build/static/media/1.cfd7137013b37c3af400.jpg"
                                  alt=""
                                  loading="lazy"
                                />
                              </div>
                              <div className=" w-100 ms-3">
                                <h6 className="mb-0 ">Bni Emma Watson</h6>
                                <small className="float-left font-size-12">
                                  13 Jun
                                </small>
                              </div>
                            </div>
                          </Link>
                          <Link to="#" className="iq-sub-card">
                            <div className="d-flex align-items-center">
                              <div className="">
                                <Image
                                  className="avatar-40 rounded"
                                  src="https://templates.iqonic.design/socialv/bs5/react/build/static/media/02.996984acbcab88366af7.jpg"
                                  alt=""
                                  loading="lazy"
                                />
                              </div>
                              <div className="ms-3">
                                <h6 className="mb-0 ">Lorem Ipsum Watson</h6>
                                <small className="float-left font-size-12">
                                  20 Apr
                                </small>
                              </div>
                            </div>
                          </Link>
                          <Link to="#" className="iq-sub-card">
                            <div className="d-flex align-items-center">
                              <div className="">
                                <Image
                                  className="avatar-40 rounded"
                                  src="https://templates.iqonic.design/socialv/bs5/react/build/static/media/01.7340bf5d971620814d9d.jpg"
                                  alt=""
                                  loading="lazy"
                                />
                              </div>
                              <div className="ms-3">
                                <h6 className="mb-0 ">Why do we use it?</h6>
                                <small className="float-left font-size-12">
                                  30 Jun
                                </small>
                              </div>
                            </div>
                          </Link>
                          <Link to="#" className="iq-sub-card">
                            <div className="d-flex align-items-center">
                              <div className="">
                                <Image
                                  className="avatar-40 rounded"
                                  src="https://templates.iqonic.design/socialv/bs5/react/build/static/media/05.803eaf62b7ba16bcfa3b.jpg"
                                  alt=""
                                  loading="lazy"
                                />
                              </div>
                              <div className="ms-3">
                                <h6 className="mb-0 ">Variations Passages</h6>
                                <small className="float-left font-size-12">
                                  12 Sep
                                </small>
                              </div>
                            </div>
                          </Link>
                          <Link to="#" className="iq-sub-card">
                            <div className="d-flex align-items-center">
                              <div className="">
                                <Image
                                  className="avatar-40 rounded"
                                  src="https://templates.iqonic.design/socialv/bs5/react/build/static/media/07.bb7d261befb8ec00b79e.jpg"
                                  alt=""
                                  loading="lazy"
                                />
                              </div>
                              <div className="ms-3">
                                <h6 className="mb-0 ">
                                  Lorem Ipsum generators
                                </h6>
                                <small className="float-left font-size-12">
                                  5 Dec
                                </small>
                              </div>
                            </div>
                          </Link>
                        </Card.Body>
                        <Card.Header className="d-flex justify-content-between bg-primary notification">
                          <Link to="/dashboard/app/chat" className="view-all-btn"><button className=" btn header-title ">
                              View All
                          </button>
                          </Link>
                          <small className="badge  bg-light text-dark">4</small>
                        </Card.Header>
                      </Card>
                    </Dropdown.Menu> */}
                  </Dropdown>
                  <Nav.Item as="li" className="d-lg-none">
                    <Link
                      to="/dashboard/app/chat"
                      className="dropdown-toggle d-flex align-items-center"
                    >
                      <i className="material-symbols-outlined">mail</i>
                      <span className="mobile-text  ms-3">Message</span>
                    </Link>
                  </Nav.Item>
                  <Dropdown as="li" className="nav-item d-none d-lg-block">
                    <Dropdown.Toggle
                      href="#"
                      as={CustomToggle}
                      variant="d-flex align-items-center"
                    >
                      <Image
                        src={userInfo?.profile_picture ? userInfo?.profile_picture : "https://jbpbucket-dev.s3.amazonaws.com/devjanbask/profile_pic/f65d1d56-5887-4abb-b4f1-a3100975g718.jpg"}
                        className="img-fluid rounded-circle me-3"
                        alt="user"
                        loading="lazy"
                        onClick={() => setShowDropdown(true)}
                      />
                      <div className="caption">
                        <h6 className="mb-0 line-height" onClick={() => setShowDropdown(true)}>
                          {userInfo?.first_name + " " + userInfo?.last_name}
                        </h6>
                      </div>
                    </Dropdown.Toggle>
                    {showDropdown ? <Dropdown.Menu className="sub-drop caption-menu">
                      <Card className="shadow-none m-0">
                        <Card.Header>
                          <div className="header-title">
                            <h5 className="mb-0 ">
                              Hello{" "}
                              {userInfo?.first_name + " " + userInfo?.last_name}
                            </h5>
                          </div>
                        </Card.Header>
                        <Card.Body className="p-0 ">
                          <div className="d-flex align-items-center iq-sub-card border-0">
                            <span className="material-symbols-outlined">
                              line_style
                            </span>
                            <div className="ms-3">
                              <Link
                                to="/dashboard/app/profile"
                                className="mb-0 h6"
                                onClick={setDropdown}
                              >
                                My Profile
                              </Link>
                            </div>
                          </div>
                          <div className="d-flex align-items-center iq-sub-card border-0">
                            <span className="material-symbols-outlined">
                              edit_note
                            </span>
                            <div className="ms-3">
                              <Link
                                to="/dashboard/app/user-profile-edit"
                                className="mb-0 h6"
                                onClick={setDropdown}
                              >
                                Edit Profile
                              </Link>
                            </div>
                          </div>
                          {/* <div className="d-flex align-items-center iq-sub-card border-0">
                                                        <span className="material-symbols-outlined">
                                                            manage_accounts
                                                        </span>
                                                        <div className="ms-3">
                                                            <Link to="/dashboard/app/user-account-setting" className="mb-0 h6">
                                                                Account settings
                                                            </Link>
                                                        </div>
                                                    </div>
                                                    <div className="d-flex align-items-center iq-sub-card border-0">
                                                        <span className="material-symbols-outlined">
                                                            lock
                                                        </span>
                                                        <div className="ms-3">
                                                            <Link to="/dashboard/app/user-privacy-setting" className="mb-0 h6">
                                                                Privacy Settings
                                                            </Link>
                                                        </div>
                                                    </div> */}
                          <div className="d-flex align-items-center iq-sub-card">
                            <span className="material-symbols-outlined">
                              login
                            </span>
                            <div className="ms-3">
                              <div
                                onClick={async () => {
                                  await dispatch(logoutUser());
                                  localStorage.clear();
                                  history.push("/auth/sign-in");
                                }}
                                className="mb-0 h6"
                              >
                                Sign out
                              </div>
                            </div>
                          </div>
                          {/* <div className=" iq-sub-card">
                                                        <h5>Chat Settings</h5>
                                                    </div>
                                                    <div className="d-flex align-items-center iq-sub-card border-0">
                                                        <i className="material-symbols-outlined text-success md-14">
                                                            circle
                                                        </i>
                                                        <div className="ms-3">
                                                            Online
                                                        </div>
                                                    </div>
                                                    <div className="d-flex align-items-center iq-sub-card border-0">
                                                        <i className="material-symbols-outlined text-warning md-14">
                                                            circle
                                                        </i>
                                                        <div className="ms-3">
                                                            Away
                                                        </div>
                                                    </div>
                                                    <div className="d-flex align-items-center iq-sub-card border-0">
                                                        <i className="material-symbols-outlined text-danger md-14">
                                                            circle
                                                        </i>
                                                        <div className="ms-3">
                                                            Disconnected
                                                        </div>
                                                    </div>
                                                    <div className="d-flex align-items-center iq-sub-card border-0">
                                                        <i className="material-symbols-outlined text-gray md-14">
                                                            circle
                                                        </i>
                                                        <div className="ms-3">
                                                            Invisible
                                                        </div>
                                                    </div> */}
                        </Card.Body>
                      </Card>
                    </Dropdown.Menu> : null}
                  </Dropdown>
                  <Nav.Item as="li" className="d-lg-none">
                    <Link
                      to="/dashboard/app/profile"
                      className="dropdown-toggle d-flex align-items-center"
                    >
                      <span className="material-symbols-outlined">person</span>
                      <span className="mobile-text  ms-3">Profile</span>
                    </Link>
                  </Nav.Item>
                </ul>
              </Offcanvas.Body>
            </div>
          </Container>
        </Navbar>
      </div>
    </>
  );
};

export default Header;
