import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import CommentInput from "../components/CommentInput";
import {
  Row,
  Col,
  Container,
  Dropdown,
  OverlayTrigger,
  Tooltip,
  Modal,
} from "react-bootstrap";

import { stateToHTML } from "draft-js-export-html";
import RenderComment from "../views/app/RenderComment";
import { convertFromRaw } from "draft-js";
import { Link } from "react-router-dom";
import Card from "./Card";
import RenderLike from "../views/ui-kit/Like";
import RenderFile from "./RenderFile";
import PostModal from "./PostModal";
import user2 from "../assets/images/user/02.jpg";
import user3 from "../assets/images/user/03.jpg";

import p1 from "../assets/images/page-img/p1.jpg";

import p2 from "../assets/images/page-img/p2.jpg";
import p3 from "../assets/images/page-img/p3.jpg";

import { getDate } from "../utilities/time";
import { get_url_extension } from "../utilities/common";
import { useGetPostsQuery } from "../store/post/postApiSlice";
import RenderMetaURL from "./RenderMetaURL";

const RenderURLDetails = ({ urlDetails, key }) => {
  return (
    <div key={`key-${urlDetails?.url}-${key}`}>
      {urlDetails && (
        <a href={urlDetails?.url} target="_blank">
          <div>
            <img src={urlDetails?.ogImage}></img>
          </div>
          <div className="scrtDx">
            <div className="scrtTitle">{urlDetails?.title}</div>
            <div className="scrtDescription">{urlDetails?.description}</div>
          </div>
        </a>
      )}
    </div>
  );
};

function FeedBlock({
  postDetails,
  handleLike,
  handleComment,
  handleCommentLike,
  handleReply,
  getPost,
}) {
  let post_id = postDetails._id;

  const [show, setShow] = useState(false);
  const userInfo = useSelector((state) => state.user.userDetails);
  const handleShow = () => {
    setShow(true);
  };

  const onSubmit = () => { };
  let timeObj = getDate(postDetails?.createdAt);
  let ArrayOfObj = [
    {
      name: "Sara",
      comment: "this story is awsome, loving it ",
      time: "4 min",
      createdAt: "2022-12-02T13:04:10.003Z",
    },
    {
      name: "Ritesh",
      comment: "yeahh great job!!!",
      time: "8 min",
      createdAt: "2022-12-02T13:04:10.003Z",
    },
    {
      name: "Yukti",
      comment: "thats a great post",
      time: "10 min",
      createdAt: "2022-12-02T13:04:10.003Z",
    },
  ];

  const convertFromJSONToHTML = (text) => {
    try {
      return { __html: stateToHTML(convertFromRaw(text)) };
    } catch (exp) {
      console.log(exp);
      return { __html: "Error" };
    }
  };

  const getUpdatedHtml = (textEditorData) => {
    function replaceURLs(message) {
      if (!message) return;
      var urlRegex = /(((https?:\/\/)|(www\.))[^\s]+)/g;

      return message.replace(urlRegex, function (url) {
        var hyperlink = url;
        hyperlink = hyperlink.replace("</p>", "");
        if (!hyperlink.match("^https?://")) {
          hyperlink = "http://" + hyperlink;
        }
        return (
          '<a href="' +
          hyperlink +
          '" target="_blank" rel="noopener noreferrer">' +
          url +
          "</a>"
        );
      });
    }
    let text = textEditorData
      ? convertFromJSONToHTML({ entityMap: {}, ...textEditorData })
      : "";
    let urlss = text?.__html?.includes("</a>")
      ? null
      : replaceURLs(text.__html);
    if (urlss) {
      text.__html = urlss;
    }
    return text;
  };

  return (
    <Col sm={12}>
      <Card className=" card-block card-stretch card-height">
        <Card.Body>
          <div className="user-post-data">
            <div className="d-flex ">
              <Link to="/dashboard/app/profile">
                <div className="me-3">
                  <img
                    className="avatar-60 rounded-circle img-fluid"
                    src={
                      postDetails?.created_by?.profile_picture ||
                      "https://jbpbucket-dev.s3.amazonaws.com/devjanbask/profile_pic/f65d1d56-5887-4abb-b4f1-a3100975g718.jpg"
                    }
                    alt=""
                  />
                </div>
              </Link>
              <div className="w-100">
                <div className="d-flex justify-content-between" style={{ position: "relative" }}>
                  <div>
                    {postDetails?.group_identifier?.name ? (
                      <h5 className="mb-0 d-inline-block">
                        {postDetails?.group_identifier?.name} by {postDetails?.created_by?.username}
                      </h5>
                    ) : (
                      <Link to="/dashboard/app/profile"><h5 className="mb-0 d-inline-block">
                        {postDetails?.created_by?.username}
                      </h5></Link>
                    )}
                    <p className="mb-0 text-primary">
                      {timeObj.hours > 0
                        ? timeObj.hours > 23
                          ? `on ${timeObj?.timeStart.toDateString()}`
                          : `${Math.floor(timeObj.hours)} hour ago`
                        : `${Math.floor(timeObj.minutes)} min ago`}
                    </p>
                  </div>
                  {postDetails?.created_by?._id === userInfo?.ref && < button className="p-image" style={{ position: "absolute", top: "5px", border: "none" }} onClick={handleShow}><i className="ri-pencil-line upload-button "></i></button>}

                </div>
                {/* {postDetails?.created_by?._id === userInfo?.ref && (
                  <button onClick={handleShow}>edit</button>
                )} */}
              </div>
            </div>
          </div>
          <div className="mt-3">
            {postDetails?.text_editor_data ? (
              <>
                <div
                  dangerouslySetInnerHTML={getUpdatedHtml(
                    postDetails?.text_editor_data
                  )}
                ></div>
                <RenderURLDetails />
              </>
            ) : (
              <p>{postDetails?.plain_text}</p>
            )}
          </div>
          <PostModal
            show={show}
            setShow={setShow}
            postDetails={postDetails}
            getPost={getPost}
          />
          <div className="user-post">
            {postDetails?.files.map((file) => {
              return (
                <div className=" d-grid grid-rows-2 grid-flow-col gap-3">
                  <div className="row-span-2 row-span-md-1">
                    <RenderFile file={file?.url} filetype={file?.file_type} />
                  </div>
                </div>
              );
            })}
            {postDetails?.url_meta_data && (
              <RenderMetaURL
                title={postDetails?.url_meta_data?.title}
                description={postDetails?.url_meta_data?.description}
                image={postDetails?.url_meta_data?.image}
              />
            )}
          </div>
          <div className="comment-area mt-3">
            <div className="d-flex justify-content-between align-items-center flex-wrap">
              <div className="like-block position-relative d-flex align-items-center">
                <div className="d-flex align-items-center">
                  <RenderLike handleLike={handleLike} data={postDetails} />
                </div>
                <div className="total-comment-block">
                  {`${postDetails?.comment_count} Comments`}
                </div>
              </div>
            </div>
            <hr />
            {postDetails?.comments.map((item) => {
              return (
                <RenderComment
                  objData={item}
                  handleReply={handleReply}
                  handleCommentLike={handleCommentLike}
                  post_id={post_id}
                />
              );
            })}

            <CommentInput handleComment={handleComment} data={postDetails} />
          </div>
        </Card.Body>
      </Card>
    </Col>
  );
}

export default FeedBlock;
