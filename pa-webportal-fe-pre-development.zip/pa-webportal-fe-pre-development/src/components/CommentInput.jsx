import React, { useState } from 'react';

function CommentInput({ handleComment, data }) {

  const [comment, setComment] = useState({
    comment_text: ""
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    handleComment(data._id, comment.comment_text);
    setComment({
      comment_text: ""
    });
  }

  const handleChange = (e) => {
    setComment({ ...comment, [e.target.name]: e.target.value })
  }

  return (
    <div style={{ position: "relative" }}>
      <form className="comment-text d-flex align-items-center mt-3"
        onSubmit={handleSubmit}
      >
        <input
          type="text"
          className="form-control rounded"
          placeholder="Enter Your Comment"
          name='comment_text'
          value={comment.comment_text}
          onChange={(e) => handleChange(e)}
        />

        <button
          style={{ border: "none", position: "absolute", right: "1%", backgroundColor: "transparent" }}
          type="submit">
          <i className="fa fa-paper-plane "></i>
        </button>
      </form>
    </div>
  )
}

export default CommentInput;