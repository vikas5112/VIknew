import React from 'react';

function RenderMetaURL ({title,description,image}){
    return (
        <div className="scrapperBox">
            <div>
                <img src={image}></img>
            </div>
            <div className="scrtDx">
                <div className="scrtTitle">{title}</div>
                <div className="scrtDescription">{description}</div>
            </div>
        </div>
    )
}

export default  RenderMetaURL;