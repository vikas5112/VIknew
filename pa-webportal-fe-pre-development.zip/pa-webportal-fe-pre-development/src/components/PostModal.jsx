import React, { useState, useEffect } from "react";
import {
  Row,
  Col,
  Container,
  Dropdown,
  OverlayTrigger,
  Tooltip,
  Modal,
} from "react-bootstrap";
import { Link } from "react-router-dom";
import TextEditor from "./TextEditor";
import RenderFile from "./RenderFile";

import {
  useUpdatePostMutation,
  useFeedUploadMutation,
} from "../store/post/postApiSlice";

export default function PostModal({ show, setShow, postDetails, getPost }) {
  const [textEditorData, setTextEditorData] = useState(null);
  const [file, setFile] = useState(null);
  const [updatePost] = useUpdatePostMutation();
  const [feedUpload] = useFeedUploadMutation();

  const user = postDetails?.created_by;
  useEffect(() => {
    if (postDetails?.text_editor_data) {
      setTextEditorData({ entityMap: {}, ...postDetails?.text_editor_data });
    }
  }, [postDetails]);

  const handleClose = () => {
    // setTextEditorData(null);
    // setFile(null)
    setShow(false);
  };

  const handleSubmit = async () => {
    let multerData = new FormData();

    multerData.append("file", file);

    let payload;
    if (file) {
      const feedRes = await feedUpload(multerData);

      if (feedRes?.data?.status === 1) {
        payload = {
          id: postDetails._id,
          text_editor_data: textEditorData,
          file_id: feedRes?.data?.data?.data?._id,
          file_url: feedRes?.data?.data?.data?.file_url,
          file_type: file?.type,
        };
      } else {
        console.log("ERROR in File upload");
        return;
      }
    } else {
      payload = {
        id: postDetails._id,
        text_editor_data: textEditorData,
      };
    }
    const result = await updatePost(payload);
    if (result?.data?.status === 1) {
      setFile(null);
      setTextEditorData(null);
      setFile(null);
      setShow(false);
      getPost.refetch();
    }
  };

  const uploadMediaHandle = (fileData) => {
    setFile(fileData);
  };
  return (
    <div>
      <Modal
        size="lg"
        className=" fade"
        id="post-modal"
        onHide={handleClose}
        show={show}
      >
        <Modal.Header className="d-flex justify-content-between">
          <Modal.Title id="post-modalLabel">Edit Post</Modal.Title>
          <Link to="#" className="lh-1" onClick={handleClose}>
            <span className="material-symbols-outlined">close</span>
          </Link>
        </Modal.Header>
        <Modal.Body>
          <div className="d-flex align-items-center">
            <div className="user-img">
              <img
                src={
                  user?.profile_picture
                    ? user?.profile_picture
                    : "https://jbpbucket-dev.s3.amazonaws.com/devjanbask/profile_pic/f65d1d56-5887-4abb-b4f1-a3100975g718.jpg"
                }
                alt="user1"
                className="avatar-60 rounded-circle img-fluid"
              />
            </div>
            <form
              className="post-text ms-3 w-100 "
              data-bs-toggle="modal"
              data-bs-target="#post-modal"
            >
              <TextEditor
                textEditorData={textEditorData}
                onChange={setTextEditorData}

                // urlDetails={urlDetails}
                // fetchUrlDetails={fetchUrlDetails}
              />
              {/* <input
            type="text"
            className="form-control rounded"
            onChange={handleTextChange}
            placeholder="Write something here..."
            style={{ border: "none" }}
          /> */}
            </form>
          </div>
          <hr />
          <ul className="d-flex flex-wrap align-items-center list-inline m-0 p-0">
            <li className="col-md-6 mb-3">
              <div className="bg-soft-primary rounded p-2 pointer me-3">
                <label className="shareOption">
                  <span>Photo/Video</span>

                  <input
                    style={{ display: "none" }}
                    type="file"
                    id="file"
                    //  accept=".png,.jpeg,.jpg"
                    onChange={(e) => {
                      uploadMediaHandle(e.target.files[0]);
                    }}
                  />
                </label>
              </div>
            </li>
            {file ? (
              <RenderFile file={file} filetype={"filetype"} />
            ) : (
              <RenderFile
                fileUrl={postDetails?.files[0]?.url}
                filetype={postDetails?.files[0]?.file_type}
              />
            )}
          </ul>
          <hr />

          <button
            type="submit"
            className="btn btn-primary d-block w-100 mt-3"
            onClick={handleSubmit}
          >
            Post
          </button>
        </Modal.Body>
      </Modal>
    </div>
  );
}
