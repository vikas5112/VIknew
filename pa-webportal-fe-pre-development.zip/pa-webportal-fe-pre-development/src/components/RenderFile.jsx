import React from "react";

import pdfIcon from "../assets/images/pdfIcon.png";
import docIcon from "../assets/images/docImg.png";

function RenderFile({ fileUrl, file, filename, filetype }) {
  if (file) {
    let typeArr = file.type ? file.type?.split("/") : filetype?.split("/");
    if (Array.isArray(typeArr) && typeArr[0] === "image") {
      return (
        <div>
          {file && (
            <img
              src={typeof file === "string" ? file : URL.createObjectURL(file)}
              style={{ width: "380px", height: "180px" }}
            />
          )}
        </div>
      );
    } else if (Array.isArray(typeArr) && typeArr[0] === "video") {
      return (
        <div>
          {/* <img
            src="https://jbpbucket-dev.s3.amazonaws.com/devjanbask/feed/videoIcon.jpg"
            style={{ width: "100px" }}
          /> */}
          <video width="100%" height="100%" controls>
            <source src={file} type="video/mp4" />
            Your browser does not support the video tag.
          </video>
          {/*<span>{` ${file.name || filename}`} </span>*/}
        </div>
      );
    } else if (Array.isArray(typeArr) && typeArr[0] === "application") {
      return (
        <div>
          <a href={file}>
            <img
              src={typeArr[1] === "pdf" ? pdfIcon : docIcon}
              style={{ width: "100px" }}
            />
          </a>

        </div>
      );
    } else {
      return <div>Undefined file type</div>;
    }
  } else if (fileUrl) {
    let typeArr = filetype ? filetype?.split("/") : null;
    if (Array.isArray(typeArr) && typeArr[0] === "image") {
      return (
        <div>
          <img src={fileUrl} style={{ width: "380px", height: "180px" }} />
        </div>
      );
    } else if (Array.isArray(typeArr) && typeArr[0] === "video") {
      return (
        <div>
          {/* <img
            src="https://jbpbucket-dev.s3.amazonaws.com/devjanbask/feed/videoIcon.jpg"
            style={{ width: "100px" }}
          /> */}
          <video width="100%" height="100%" controls>
            <source src={fileUrl} type="video/mp4" />
            Your browser does not support the video tag.
          </video>
          {/*<span>{` ${file.name || filename}`} </span>*/}
        </div>
      );
    } else if (Array.isArray(typeArr) && typeArr[0] === "application") {
      return (
        <div>
          <a href={fileUrl}>
            <img
              src={typeArr[1] === "pdf" ? pdfIcon : docIcon}
              style={{ width: "100px" }}
            />
          </a>

          {/*<span>{` ${file.name || filename}`} </span>*/}
        </div>
      );
    } else {
      return <div>Undefined file type</div>;
    }
  } else {
    return null;
  }
}

export default RenderFile;
