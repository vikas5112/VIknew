import React, { useEffect } from "react";
import { Switch, Route, Redirect, useHistory,useLocation } from "react-router-dom";
import Default from "../layouts/Default";
import WithoutLeftSidebar from "../layouts/WithoutLeftsidebar";
import WithoutRightSidebar from "../layouts/WithoutRightsidebar";
import Layout1 from "../layouts/Layout1";
import Simple from "../layouts/Simple";
var state={}
const IndexRouters = () => {
  const history = useHistory();
  state = useLocation()?.state;
  const token = localStorage.getItem("token");
  useEffect(() => {
    if (token) {
      history.push("/dashboard");
    } else {
      history.push("/auth/sign-in");
    }
  }, [token]);
  return (
    <>
      {!token ? (
        <Switch>
          <Route path="/errors" component={Simple}></Route>
          <Route path="/extra-pages" component={Simple}></Route>
          <Route path="/auth" component={Simple}></Route>
        </Switch>
      ) : (
        <Switch>
          <Route exact path="/">
            {<Redirect to="/dashboard" />}
          </Route>
          <Route path="/dashboard" component={Default}></Route>
          <Route
            path="/without-leftsidebar"
            component={WithoutLeftSidebar}
          ></Route>
          <Route
            path="/without-rightsidebar"
            component={WithoutRightSidebar}
          ></Route>
          <Route path="/dashboards" component={Layout1}></Route>
        </Switch>
      )}
    </>
  );
};

export default IndexRouters;
