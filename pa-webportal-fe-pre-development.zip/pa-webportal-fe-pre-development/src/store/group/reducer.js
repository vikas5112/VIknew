import {createSlice} from "@reduxjs/toolkit";
const initialState = {
    data:{}
};

export const groupSlice = createSlice({
  name: "group",
  initialState,
  reducers: {
    setGroup: (state,action) =>{
      state.group = action.payload
    }
  },
});

export default groupSlice.reducer;
