import { apiSlice } from "../apiSlice";

export const groupApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({

    getGroups: builder.query({
      query: () => ({
        url: `groups/get-group-details`,
        method: 'GET',
      })
    }),
    addMember: builder.mutation({
      query: (data) => ({
          url: `groups/add-group-member`,
          method: "PATCH",
          body: {...data },
        }),
  }),
  removeMember:builder.mutation({
    query: (data) => ({
        url: `groups/remove-group-member`,
        method: "DELETE",
        body: {...data },
      }),
}),
    editGroupDetail: builder.mutation({
      query: (data) => ({
        url: `groups/update-group-details`,
        method: "PATCH",
        body: { ...data },
      }),
    }),
    deleteGroup : builder.mutation({
      query: (data) => ({
        url: `groups/remove-group`,
        method: "DELETE",
        body : {...data}
      })
    }),
  }),
});

export const {
useGetGroupsQuery,
useAddMemberMutation,
useRemoveMemberMutation,
useEditGroupDetailMutation,
useDeleteGroupMutation
} = groupApiSlice;
