import {groupSlice} from './reducer'

export const {
   setGroup
} = groupSlice.actions;
export default groupSlice.actions;
