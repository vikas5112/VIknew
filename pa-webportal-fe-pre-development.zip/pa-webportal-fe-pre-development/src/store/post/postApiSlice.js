import { apiSlice } from "../apiSlice";

export const postApiSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getPosts: builder.query({
      query: () => ({
        url: "posts/get-all-post/0/1",
        method: "GET",
      }),
    }),
    getPostsForUser: builder.query({
      query: () => ({
        url: "posts/get-post-by-user_id",
        method: "GET",
      }),
    }),
    getPostsForGroup: builder.query({
      query: (id) => ({
        url: `/posts/get-group-post/${id}`,
        method: "GET",
      }),
    }),
    createPost: builder.mutation({
      query: (data) => ({
        url: "/posts/create-post",
        method: "POST",
        body: data,
      }),
    }),
    getUrlMeta: builder.mutation({
      query: (data) => ({
        url: "/posts/url-meta-data",
        method: "POST",
        body: data,
      }),
    }),
    createGroupPost: builder.mutation({
      query: (data) => ({
        url: `/posts/create-post/${data?.group_id}`,
        method: "POST",
        body: data,
      }),
    }),

    
    updatePost: builder.mutation({
      query: (data) => ({
        url: `/posts/update-post/${data.id}`,
        method: "PUT",
        body: data,
      }),
    }),
    feedUpload: builder.mutation({
      query: (data) => ({
        url: "/aws/upload_feed",
        method: "POST",
        body: data,
      }),
    }),
    likePost: builder.mutation({
      query: (data) => ({
        url: "/like/like-post",
        method: "POST",
        body: data,
      }),
    }),
    likeComment: builder.mutation({
      query: (data) => ({
        url: "/like/like-comment",
        method: "POST",
        body: data,
      }),
    }),
    createComment: builder.mutation({
      query: (data) => ({
        url: `comments/add-comment`,
        method: "POST",
        body: data,
      }),
    }),
  }),
});

export const {
  useGetPostsQuery,
  useCreatePostMutation,
  useCreateGroupPostMutation,
  useFeedUploadMutation,
  useLikePostMutation,
  useCreateCommentMutation,
  useLikeCommentMutation,
  useUpdatePostMutation,
  useGetPostsForUserQuery,
  useGetUrlMetaMutation,
  useGetPostsForGroupQuery
} = postApiSlice;
