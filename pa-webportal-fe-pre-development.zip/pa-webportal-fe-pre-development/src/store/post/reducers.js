import { createSlice,createAsyncThunk } from "@reduxjs/toolkit";
import _ from "lodash";
import config from "../redux/config.json"
const initialState = {};


export const postSlice = createSlice({
  name: "post",
  initialState,
  reducers: {
    getAllPosts: async (state, action) => {
        
    },
  },
});

export default postSlice.reducer;
