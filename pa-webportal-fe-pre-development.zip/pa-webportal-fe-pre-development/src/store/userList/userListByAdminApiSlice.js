
import { apiSlice } from "../apiSlice";

export const userListByAdminApiSlice = apiSlice.injectEndpoints({
    endpoints: (builder) => ({
        getUserListByAdmin: builder.query({
            query: (searchTerm) => ({
              url: `users/get-all-users/${searchTerm}`,
              method: "GET",
            }),
          }),
    })
})



export const {
    useGetUserListByAdminQuery
} = userListByAdminApiSlice