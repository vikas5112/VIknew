import { userListSlice } from "./reducers";
export const { userListByAdmin } = userListSlice.actions;
