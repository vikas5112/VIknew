import {apiSlice} from "../apiSlice"

export const connectionApiSlice=apiSlice.injectEndpoints({
    endpoints:builder=>({
        getConnection:builder.query({
            query:()=>({
                url:'connections/get-connections',
                method:'GET',
            })
        }),
       
        getInvitations:builder.query({
            query:()=>({
                url:'connections/get-invitation-count',
                method:'GET',
            })
        }),
        updateStatus:builder.mutation({
            query: (data) => ({
                url: `connections/update-status/${data.id}`,
                method: "PUT",
                body: { status:data.status },
              }),
        }),
        createConnection:builder.mutation({
            query: (data) => ({
                url: `connections`,
                method: "POST",
                body: data,
              }),
        })
    })
})

export const {
    useGetConnectionQuery,
    useUpdateStatusMutation,
    useGetInvitationsQuery,
    useCreateConnectionMutation
}=connectionApiSlice