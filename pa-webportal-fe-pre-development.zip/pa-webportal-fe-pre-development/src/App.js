//router
import IndexRouters from "./router/index"

//--scss
import "./assets/scss/socialv.scss"
import "./assets/scss/customizer.scss"

import {ErrorBoundary} from "./views/errors/ErrorHandler"
function App() {
  return (
    <div className="App">
      <ErrorBoundary>

      <IndexRouters />
      </ErrorBoundary>
    </div>
  );
}

export default App;
